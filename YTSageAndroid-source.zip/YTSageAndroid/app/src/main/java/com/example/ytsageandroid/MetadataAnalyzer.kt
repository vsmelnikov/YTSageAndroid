package com.example.ytsageandroid

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File

object MetadataAnalyzer {
    data class FormatInfo(val height: Int, val estimatedBytes: Long)
    data class Entry(val id: String, val title: String, val url: String, val thumbnail: String, val duration: Int)
    data class Result(
        val title: String,
        val thumbnail: String,
        val durationSeconds: Int,
        val isPlaylist: Boolean,
        val entries: List<Entry>,
        val formats: List<FormatInfo>,
        val estimatedBytes: Long,
        val audioEstimatedBytes: Long,
        val message: String
    )

    fun analyze(context: Context, url: String, cookies: File): Result {
        val request = YoutubeDLRequest(url).apply {
            addOption("--dump-single-json"); addOption("--skip-download"); addOption("--no-warnings")
            addOption("--ignore-errors"); addOption("--flat-playlist"); addOption("--no-call-home")
            if (cookies.exists() && cookies.length() > 0) addOption("--cookies", cookies.absolutePath)
        }
        val response = YoutubeDL.getInstance().execute(request, "YTSageAnalyze") { _, _, _ -> kotlin.Unit }
        val output = response.out
        val start = output.indexOf('{'); val end = output.lastIndexOf('}')
        if (start < 0 || end <= start) error(output.takeLast(800).ifBlank { context.getString(R.string.metadata_no_json) })
        val root = JSONObject(output.substring(start, end + 1))
        val fallbackTitle = context.getString(R.string.unknown_title)
        val title = root.optString("title", fallbackTitle).ifBlank { fallbackTitle }
        val thumbnail = root.optString("thumbnail")
        val duration = root.optDouble("duration", 0.0).toInt().coerceAtLeast(0)
        val entriesJson = root.optJSONArray("entries")
        val entries = mutableListOf<Entry>()
        if (entriesJson != null) for (i in 0 until entriesJson.length()) {
            val e = entriesJson.optJSONObject(i) ?: continue
            val id = e.optString("id")
            val entryUrl = sequenceOf(e.optString("webpage_url"), e.optString("original_url"), e.optString("url"))
                .firstOrNull { it.startsWith("http://") || it.startsWith("https://") }
                ?: if (id.isNotBlank()) "https://www.youtube.com/watch?v=$id" else ""
            if (entryUrl.isNotBlank()) entries += Entry(id, e.optString("title", context.getString(R.string.playlist_item, i + 1)), entryUrl,
                e.optString("thumbnail"), e.optDouble("duration", 0.0).toInt().coerceAtLeast(0))
        }
        val formats = mutableMapOf<Int, Long>()
        var audioEstimated = 0L
        val fa = root.optJSONArray("formats")
        if (fa != null) for (i in 0 until fa.length()) {
            val f = fa.optJSONObject(i) ?: continue
            val h = f.optInt("height", 0); val videoCodec = f.optString("vcodec", "none")
            val audioCodec = f.optString("acodec", "none")
            val bytes = f.optLong("filesize", 0L).takeIf { it > 0 }
                ?: f.optLong("filesize_approx", 0L).takeIf { it > 0 } ?: 0L
            if (h > 0 && videoCodec != "none" && bytes > (formats[h] ?: 0L)) formats[h] = bytes
            if (audioCodec != "none" && videoCodec == "none" && bytes > audioEstimated) audioEstimated = bytes
        }
        val formatList = formats.entries.sortedByDescending { it.key }.map { FormatInfo(it.key, it.value) }
        val estimated = if (formatList.isEmpty()) 0L else formatList.firstOrNull { it.height == formatList.maxOf { f -> f.height } }?.estimatedBytes ?: 0L
        val playlist = entries.isNotEmpty() || root.optString("_type") == "playlist"
        val msg = when {
            playlist -> context.getString(R.string.playlist_items_count, entries.size)
            formatList.isNotEmpty() -> context.getString(R.string.formats_found, formatList.joinToString { "${it.height}p" })
            else -> context.getString(R.string.metadata_basic)
        }
        return Result(title, thumbnail, duration, playlist, entries, formatList, estimated, audioEstimated, msg)
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "—"
    val mb = bytes / 1024.0 / 1024.0
    return if (mb >= 1024.0) String.format(java.util.Locale.US, "~%.2f GB", mb / 1024.0)
    else String.format(java.util.Locale.US, "~%.0f MB", mb)
}

fun parseTimecode(value: String): Int? {
    val parts = value.trim().split(":")
    if (parts.size != 3 || parts.any { it.isBlank() || it.any { c -> !c.isDigit() } }) return null
    val h = parts[0].toIntOrNull() ?: return null
    val m = parts[1].toIntOrNull() ?: return null
    val s = parts[2].toIntOrNull() ?: return null
    if (m !in 0..59 || s !in 0..59) return null
    val total = h.toLong() * 3600L + m.toLong() * 60L + s.toLong()
    if (total > Int.MAX_VALUE) return null
    return total.toInt()
}

fun formatTimecode(seconds: Int): String {
    val s = seconds.coerceAtLeast(0)
    return String.format(java.util.Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}
