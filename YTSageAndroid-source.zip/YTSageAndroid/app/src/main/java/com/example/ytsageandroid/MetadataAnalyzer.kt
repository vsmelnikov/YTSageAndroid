package com.example.ytsageandroid

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File

 data class QualityOption(val height: Int, val estimatedBytes: Long?, val formatId: String?) {
    val label: String get() = "${height}p · ${estimatedBytes?.let(::formatBytes) ?: "—"}"
}

data class PlaylistVideo(val id: String, val url: String, val title: String, val thumbnail: String?, val duration: Int?)
data class VideoMetadata(
    val title: String,
    val thumbnail: String?,
    val duration: Int?,
    val qualities: List<QualityOption>,
    val playlist: List<PlaylistVideo>,
    val isPlaylist: Boolean
)

fun analyzeUrl(context: Context, url: String, cookies: File): VideoMetadata {
    val request = YoutubeDLRequest(url).apply {
        addOption("--dump-single-json")
        addOption("--skip-download")
        addOption("--no-warnings")
        addOption("--ignore-errors")
        addOption("--flat-playlist")
        if (cookies.exists() && cookies.length() > 0) addOption("--cookies", cookies.absolutePath)
    }
    val response = YoutubeDL.getInstance().execute(request, "YTSageMetadata") { _, _, _ -> kotlin.Unit }
    val raw = response.out
    val first = raw.indexOf('{')
    val last = raw.lastIndexOf('}')
    if (first < 0 || last <= first) error(raw.takeLast(600).ifBlank { "yt-dlp did not return metadata JSON" })
    val root = JSONObject(raw.substring(first, last + 1))
    val title = root.optString("title", "Без названия").ifBlank { "Без названия" }
    val thumbnail = root.optString("thumbnail").takeIf { it.startsWith("http") }
    val duration = root.optInt("duration", -1).takeIf { it >= 0 }

    val entries = mutableListOf<PlaylistVideo>()
    val playlistArray = root.optJSONArray("entries")
    if (playlistArray != null) {
        for (i in 0 until playlistArray.length()) {
            val entry = playlistArray.optJSONObject(i) ?: continue
            val id = entry.optString("id")
            val entryUrl = entry.optString("url").takeIf { it.startsWith("http") }
                ?: entry.optString("webpage_url").takeIf { it.startsWith("http") }
                ?: id.takeIf { it.isNotBlank() }?.let { "https://www.youtube.com/watch?v=$it" }
                ?: continue
            entries += PlaylistVideo(
                id = id.ifBlank { entryUrl }, url = entryUrl,
                title = entry.optString("title", "Видео ${i + 1}"),
                thumbnail = entry.optString("thumbnail").takeIf { it.startsWith("http") },
                duration = entry.optInt("duration", -1).takeIf { it >= 0 }
            )
        }
    }

    val sizeByHeight = linkedMapOf<Int, Pair<Long?, String?>>()
    val formats = root.optJSONArray("formats")
    if (formats != null) for (i in 0 until formats.length()) {
        val f = formats.optJSONObject(i) ?: continue
        val height = f.optInt("height", 0)
        val vcodec = f.optString("vcodec", "none")
        if (height <= 0 || vcodec == "none") continue
        val size = when {
            f.has("filesize") && !f.isNull("filesize") -> f.optLong("filesize", -1).takeIf { it > 0 }
            f.has("filesize_approx") && !f.isNull("filesize_approx") -> f.optLong("filesize_approx", -1).takeIf { it > 0 }
            else -> null
        }
        val formatId = f.optString("format_id").takeIf { it.isNotBlank() }
        val existing = sizeByHeight[height]
        if (existing == null || (size != null && (existing.first == null || size > existing.first!!))) {
            sizeByHeight[height] = size to formatId
        }
    }
    val qualityOptions = sizeByHeight.map { (height, data) -> QualityOption(height, data.first, data.second) }
        .sortedByDescending { it.height }

    val isPlaylist = entries.isNotEmpty() || root.optString("_type") == "playlist"
    return VideoMetadata(title, thumbnail, duration, qualityOptions, entries, isPlaylist)
}

fun formatBytes(bytes: Long): String {
    val units = listOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var index = 0
    while (value >= 1024 && index < units.lastIndex) { value /= 1024; index++ }
    return if (index == 0) "${bytes} ${units[index]}" else "%.1f %s".format(java.util.Locale.US, value, units[index])
}

fun parseTimeCode(value: String): Int? {
    val parts = value.trim().split(":")
    if (parts.isEmpty() || parts.size > 3 || parts.any { it.isBlank() || it.toIntOrNull() == null }) return null
    val nums = parts.map { it.toInt() }
    if (nums.any { it < 0 }) return null
    return when (nums.size) {
        1 -> nums[0]
        2 -> if (nums[1] < 60) nums[0] * 60 + nums[1] else null
        else -> if (nums[1] < 60 && nums[2] < 60) nums[0] * 3600 + nums[1] * 60 + nums[2] else null
    }
}

fun secondsToTimeCode(seconds: Int): String = "%02d:%02d:%02d".format(seconds / 3600, (seconds % 3600) / 60, seconds % 60)
