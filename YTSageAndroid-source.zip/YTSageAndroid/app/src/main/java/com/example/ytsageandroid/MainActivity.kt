package com.example.ytsageandroid

import android.os.Bundle
import android.content.ContentValues
import android.net.Uri
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.os.Environment
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLException
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.ffmpeg.FFmpeg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.net.URI

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YtSageApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun YtSageApp() {
    var url by remember { mutableStateOf("") }
    var format by remember { mutableStateOf("Видео · MP4") }
    var status by remember { mutableStateOf("Подготовка движка загрузки…") }
    var engineReady by remember { mutableStateOf(false) }
    var downloading by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var eta by remember { mutableStateOf("") }
    val context = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    LaunchedEffect(Unit) {
        val result = withContext(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(context)
                FFmpeg.getInstance().init(context)
                null
            } catch (e: Exception) {
                e.message ?: "Не удалось инициализировать движок"
            }
        }
        if (result == null) {
            engineReady = true
            status = "Движок готов. Можно скачивать."
        } else {
            status = "Ошибка запуска движка: $result"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("YTSage Android", fontWeight = FontWeight.Bold) }) }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize()
                    .verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Загрузка", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Ссылка на видео") },
                    minLines = 2,
                    enabled = !downloading
                )
                Text("Формат", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = format == "Видео · MP4",
                        onClick = { format = "Видео · MP4" },
                        enabled = !downloading,
                        label = { Text("Видео · MP4") }
                    )
                    FilterChip(
                        selected = format == "Аудио · MP3",
                        onClick = { format = "Аудио · MP3" },
                        enabled = !downloading,
                        label = { Text("Аудио · MP3") }
                    )
                }

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Текущая загрузка", style = MaterialTheme.typography.titleMedium)
                        LinearProgressIndicator(
                            progress = { if (downloading) progress / 100f else 0f },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(if (downloading) "${progress.toInt()}%  $eta" else "Нет активных загрузок")
                    }
                }

                Button(
                    onClick = {
                        val parsed = try { URI(url.trim()) } catch (_: Exception) { null }
                        if (parsed == null || parsed.scheme !in listOf("http", "https") || parsed.host.isNullOrBlank()) {
                            status = "Проверь ссылку: нужен полный адрес, начинающийся с https://"
                        } else if (!engineReady) {
                            status = "Движок ещё не готов. Подожди или проверь ошибку ниже."
                        } else {
                            downloading = true
                            progress = 0f
                            eta = ""
                            status = "Запускаю загрузку…"
                            scope.launch {
                                val result = withContext(Dispatchers.IO) {
                                    try {
                                        val downloads = File(
                                            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir,
                                            "YTSageAndroid"
                                        )
                                        if (!downloads.exists() && !downloads.mkdirs()) {
                                            error("Не удалось создать рабочую папку приложения")
                                        }
                                        val existingNames = downloads.listFiles()?.map { it.name }?.toSet() ?: emptySet()

                                        val request = YoutubeDLRequest(url.trim())
                                        request.addOption("--no-playlist")
                                        request.addOption("--newline")
                                        request.addOption("--no-overwrites")
                                        request.addOption("-o", File(downloads, "%(title)s.%(ext)s").absolutePath)

                                        if (format == "Аудио · MP3") {
                                            request.addOption("-x")
                                            request.addOption("--audio-format", "mp3")
                                        } else {
                                            request.addOption("-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best")
                                            request.addOption("--merge-output-format", "mp4")
                                        }

                                        YoutubeDL.getInstance().execute(request, null) { percent, etaSeconds, _ ->
                                            mainHandler.post {
                                                progress = percent.coerceIn(0f, 100f)
                                                eta = if (etaSeconds > 0) "Осталось примерно ${etaSeconds} сек." else ""
                                            }
                                        }

                                        val output = downloads.listFiles()
                                            ?.filter {
                                                it.isFile && it.name !in existingNames &&
                                                    !it.name.endsWith(".part") && !it.name.endsWith(".ytdl")
                                            }
                                            ?.maxByOrNull { it.lastModified() }
                                            ?: error("yt-dlp завершился, но итоговый файл не найден")

                                        publishToDownloads(context, output)
                                        "Готово! Файл сохранён в Загрузки/YTSageAndroid."
                                    } catch (e: Exception) {
                                        "Ошибка загрузки: ${e.message ?: e.javaClass.simpleName}"
                                    }
                                }
                                status = result
                                downloading = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !downloading
                ) {
                    Text(if (downloading) "Загрузка…" else "Скачать")
                }

                Text(status, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Файлы сохраняются в Загрузки/YTSageAndroid. Используй приложение только для контента, который имеешь право скачивать.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                HorizontalDivider()
                Text(
                    "Версия 0.2.0 · Подключён yt-dlp и FFmpeg",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}



private fun publishToDownloads(context: android.content.Context, source: File) {
    val extension = source.extension.lowercase()
    val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
        ?: if (extension == "mp3") "audio/mpeg" else "video/mp4"

    val values = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, source.name)
        put(MediaStore.Downloads.MIME_TYPE, mimeType)
        put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/YTSageAndroid")
        put(MediaStore.Downloads.IS_PENDING, 1)
    }

    val resolver = context.contentResolver
    val uri: Uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        ?: error("Android не разрешил сохранить файл в папку Загрузки")

    try {
        resolver.openOutputStream(uri)?.use { output ->
            FileInputStream(source).use { input -> input.copyTo(output) }
        } ?: error("Не удалось открыть файл для сохранения")
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    } catch (e: Exception) {
        resolver.delete(uri, null, null)
        throw e
    }
}
