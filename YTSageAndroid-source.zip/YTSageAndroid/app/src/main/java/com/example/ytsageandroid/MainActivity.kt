package com.example.ytsageandroid

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YtSageApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun YtSageApp() {
    var url by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Вставь ссылку на видео") }
    var format by remember { mutableStateOf("Видео · MP4") }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(topBar = { TopAppBar(title = { Text("YTSage Android", fontWeight = FontWeight.Bold) }) }) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Загрузка", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Ссылка на видео или плейлист") }, minLines = 2
                )
                Text("Формат", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = format == "Видео · MP4", onClick = { format = "Видео · MP4" }, label = { Text("Видео") })
                    FilterChip(selected = format == "Аудио · MP3", onClick = { format = "Аудио · MP3" }, label = { Text("Аудио") })
                }
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Очередь загрузок", style = MaterialTheme.typography.titleMedium)
                        LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth())
                        Text("Пока нет активных загрузок", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Button(onClick = { status = if (url.startsWith("http")) "Ссылка принята. Подключение движка загрузки — следующий этап." else "Проверь ссылку: она должна начинаться с http:// или https://" }, modifier = Modifier.fillMaxWidth()) {
                    Text("Проверить ссылку")
                }
                Text(status, style = MaterialTheme.typography.bodyMedium)
                HorizontalDivider()
                Text("Версия 0.1.0 · Ранний прототип интерфейса", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
