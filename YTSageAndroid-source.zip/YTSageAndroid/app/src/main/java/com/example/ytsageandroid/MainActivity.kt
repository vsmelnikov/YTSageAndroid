package com.example.ytsageandroid

import android.content.Context
import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            YoutubeDL.getInstance().init(this)
            FFmpeg.getInstance().init(this)
        } catch (e: Exception) {
            android.util.Log.e("YTSage", "Engine initialization failed", e)
        }
        setContent { YtSageApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun YtSageApp(activity: MainActivity) {
    var url by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Вставь ссылку на видео") }
    var format by remember { mutableStateOf("Видео · MP4") }
    var progress by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    var qualities by remember { mutableStateOf(listOf<Int>()) }
    var selectedQuality by remember { mutableStateOf<Int?>(null) }
    var qualityMenu by remember { mutableStateOf(false) }
    var cookiesLoaded by remember { mutableStateOf(File(activity.filesDir, "cookies.txt").exists()) }
    val scope = rememberCoroutineScope()
    val processId = "YTSageDownload"
    val cookiesFile = remember { File(activity.filesDir, "cookies.txt") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    try {
                        activity.contentResolver.openInputStream(uri)?.use { input ->
                            cookiesFile.outputStream().use { output -> input.copyTo(output) }
                        } ?: error("Не удалось открыть файл")
                        val firstLines = cookiesFile.readLines().take(20)
                        if (firstLines.none { it.contains("# Netscape HTTP Cookie File") || it.contains(".youtube.com") || it.contains("youtube.com") }) {
                            cookiesFile.delete()
                            error("Файл не похож на cookies.txt в формате Netscape")
                        }
                        "Файл cookies загружен локально"
                    } catch (e: Exception) {
                        cookiesFile.delete()
                        "Ошибка импорта cookies: ${e.message ?: "неизвестная ошибка"}"
                    }
                }
                cookiesLoaded = cookiesFile.exists()
                status = result
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(topBar = { TopAppBar(title = { Text("YTSage Android", fontWeight = FontWeight.Bold) }) }) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Загрузка", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Ссылка на видео или плейлист") }, minLines = 2,
                    enabled = !busy
                )
                Text("Формат", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = format == "Видео · MP4", onClick = { format = "Видео · MP4" }, label = { Text("Видео") }, enabled = !busy)
                    FilterChip(selected = format == "Аудио · MP3", onClick = { format = "Аудио · MP3" }, label = { Text("Аудио") }, enabled = !busy)
                }
                if (format == "Видео · MP4") {
                    ExposedDropdownMenuBox(expanded = qualityMenu, onExpandedChange = { qualityMenu = !qualityMenu }) {
                        OutlinedTextField(
                            value = selectedQuality?.let { "${it}p" } ?: "Лучшее доступное",
                            onValueChange = {}, readOnly = true, label = { Text("Качество") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = qualityMenu) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(), enabled = !busy
                        )
                        ExposedDropdownMenu(expanded = qualityMenu, onDismissRequest = { qualityMenu = false }) {
                            DropdownMenuItem(text = { Text("Лучшее доступное") }, onClick = { selectedQuality = null; qualityMenu = false })
                            qualities.forEach { height ->
                                DropdownMenuItem(text = { Text("${height}p") }, onClick = { selectedQuality = height; qualityMenu = false })
                            }
                        }
                    }
                    Text("Сначала нажми «Анализировать», чтобы получить доступные разрешения.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Очередь загрузок", style = MaterialTheme.typography.titleMedium)
                        LinearProgressIndicator(progress = { progress.coerceIn(0f, 100f) / 100f }, modifier = Modifier.fillMaxWidth())
                        Text(if (busy) "${progress.toInt()}%" else status, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Button(
                    onClick = {
                        if (url.isBlank() || !url.trim().startsWith("http")) { status = "Проверь ссылку: она должна начинаться с http:// или https://"; return@Button }
                        busy = true; status = "Анализирую доступные форматы…"; qualities = emptyList(); selectedQuality = null
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { inspectFormats(activity, url.trim(), cookiesFile) }
                            qualities = result.first
                            status = result.second
                            busy = false
                        }
                    }, modifier = Modifier.fillMaxWidth(), enabled = !busy
                ) { Text("Анализировать ссылку") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = {
                        if (url.isBlank() || !url.trim().startsWith("http")) { status = "Сначала вставь корректную ссылку"; return@Button }
                        busy = true; progress = 0f; status = "Запускаю загрузку…"
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                download(activity, url.trim(), format, selectedQuality, cookiesFile) { value, line ->
                                    activity.runOnUiThread { progress = value; status = line }
                                }
                            }
                            status = result; busy = false
                            if (result.startsWith("Готово")) progress = 100f
                        }
                    }, modifier = Modifier.weight(1f), enabled = !busy) { Text("Скачать") }
                    OutlinedButton(onClick = {
                        try { YoutubeDL.getInstance().destroyProcessById(processId); status = "Остановка запрошена" }
                        catch (e: Exception) { status = "Не удалось остановить: ${e.message}" }
                        busy = false
                    }, modifier = Modifier.weight(1f), enabled = busy) { Text("Стоп") }
                }
                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                    Text(if (cookiesLoaded) "Заменить cookies.txt" else "Загрузить cookies.txt")
                }
                if (cookiesLoaded) {
                    Text("Cookies сохранены только в памяти приложения.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { cookiesFile.delete(); cookiesLoaded = false; status = "Cookies удалены" }, enabled = !busy) { Text("Удалить cookies") }
                } else {
                    Text("Cookies необязательны. Нужен файл Netscape cookies.txt, если YouTube требует подтверждение входа.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedButton(onClick = {
                    if (busy) return@OutlinedButton
                    busy = true; status = "Обновляю yt-dlp…"
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            try {
                                val update = YoutubeDL.getInstance().updateYoutubeDL(activity, YoutubeDL.UpdateChannel._STABLE)
                                "Обновление: $update · версия ${YoutubeDL.getInstance().versionName(activity)}"
                            } catch (e: Exception) { "Ошибка обновления: ${e.message}" }
                        }
                        status = result; busy = false
                    }
                }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Обновить yt-dlp (Stable)") }
                Text(status, style = MaterialTheme.typography.bodyMedium)
                HorizontalDivider()
                Text("Версия 0.3.2 · yt-dlp Android engine", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun makeRequest(url: String, cookies: File): YoutubeDLRequest {
    return YoutubeDLRequest(url).apply {
        addOption("--no-warnings")
        addOption("--no-mtime")
        if (cookies.exists() && cookies.length() > 0) addOption("--cookies", cookies.absolutePath)
    }
}

private fun inspectFormats(context: Context, url: String, cookies: File): Pair<List<Int>, String> {
    return try {
        val request = makeRequest(url, cookies).apply {
            addOption("--dump-single-json")
            addOption("--skip-download")
        }
        val response = YoutubeDL.getInstance().execute(request, "YTSageInspect") { _, _, _ -> kotlin.Unit }
        val output = response.out
        val start = output.indexOf('{')
        val end = output.lastIndexOf('}')
        if (start < 0 || end <= start) error(output.takeLast(700).ifBlank { "yt-dlp не вернул JSON" })
        val root = JSONObject(output.substring(start, end + 1))
        val formats = root.optJSONArray("formats")
        val heights = mutableSetOf<Int>()
        if (formats != null) for (i in 0 until formats.length()) {
            val item = formats.optJSONObject(i) ?: continue
            val height = item.optInt("height", 0)
            val vcodec = item.optString("vcodec", "none")
            if (height > 0 && vcodec != "none") heights.add(height)
        }
        val sorted = heights.sortedDescending()
        sorted to if (sorted.isEmpty()) "Анализ завершён, но список разрешений не получен. Можно попробовать «Лучшее доступное»." else "Найдено разрешений: ${sorted.joinToString { "${it}p" }}"
    } catch (e: Exception) {
        emptyList<Int>() to "Ошибка анализа: ${e.message ?: e.javaClass.simpleName}"
    }
}

private fun publishToDownloads(activity: MainActivity, source: File): String {
    val mimeType = when (source.extension.lowercase(Locale.ROOT)) {
        "mp4" -> "video/mp4"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        else -> "application/octet-stream"
    }

    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, source.name)
        put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
        put(
            MediaStore.MediaColumns.RELATIVE_PATH,
            "${Environment.DIRECTORY_DOWNLOADS}/YTSageAndroid"
        )
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }

    val resolver = activity.contentResolver
    val destination = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        ?: error("Android не смог создать файл в общей папке Загрузки")

    try {
        resolver.openOutputStream(destination, "w")?.use { output ->
            source.inputStream().use { input -> input.copyTo(output) }
        } ?: error("Не удалось открыть файл назначения")

        val publishValues = ContentValues().apply {
            put(MediaStore.MediaColumns.IS_PENDING, 0)
        }
        resolver.update(destination, publishValues, null, null)
        source.delete()
        return source.name
    } catch (e: Exception) {
        resolver.delete(destination, null, null)
        throw e
    }
}

private fun download(
    activity: MainActivity,
    url: String,
    format: String,
    quality: Int?,
    cookies: File,
    onProgress: (Float, String) -> Unit
): String {
    return try {
        // Scoped storage: download privately first; publish finished media via MediaStore.
        // This does not require broad storage permissions on Android 10+.
        val appDownloads = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(activity.filesDir, "Downloads")
        val dir = File(appDownloads, "YTSageAndroid")
        if (!dir.exists() && !dir.mkdirs()) error("Не удалось создать временную папку приложения")

        val before = dir.listFiles()?.associate { it.absolutePath to (it.lastModified() to it.length()) }
            ?: emptyMap()
        val startedAt = System.currentTimeMillis()

        val request = makeRequest(url, cookies).apply {
            addOption("-o", File(dir, "%(title).180B [%(id)s].%(ext)s").absolutePath)
            if (format == "Аудио · MP3") {
                addOption("-x")
                addOption("--audio-format", "mp3")
                addOption("--audio-quality", "0")
            } else {
                val selector = if (quality == null) "bestvideo+bestaudio/best" else "bestvideo[height<=${quality}]+bestaudio/best[height<=${quality}]"
                addOption("-f", selector)
                addOption("--merge-output-format", "mp4")
            }
        }

        val response = YoutubeDL.getInstance().execute(request, "YTSageDownload") { percent, eta, line ->
            onProgress(percent, if (line.isBlank()) "Загрузка… ETA ${eta}s" else line)
            kotlin.Unit
        }

        val supportedExtensions = setOf("mp4", "mp3", "m4a", "webm", "mkv")
        val completedFiles = dir.listFiles()?.filter { file ->
            if (!file.isFile || file.extension.lowercase(Locale.ROOT) !in supportedExtensions) {
                false
            } else {
                val old = before[file.absolutePath]
                old == null || old.first != file.lastModified() || old.second != file.length() ||
                    file.lastModified() >= startedAt - 2000
            }
        } ?: emptyList()

        if (completedFiles.isEmpty()) {
            error("yt-dlp завершился, но готовый медиафайл не найден. ${response.out.takeLast(300)}")
        }

        val published = completedFiles.map { publishToDownloads(activity, it) }
        "Готово. Сохранено в Загрузки/YTSageAndroid:\n${published.joinToString("\n")}"
    } catch (e: Exception) {
        "Ошибка загрузки: ${e.message ?: e.javaClass.simpleName}"
    }
}
