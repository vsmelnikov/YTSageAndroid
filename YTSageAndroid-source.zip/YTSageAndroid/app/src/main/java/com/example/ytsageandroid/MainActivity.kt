package com.example.ytsageandroid

import android.Manifest
import android.content.Context
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun attachBaseContext(newBase: Context) {
        val language = newBase.getSharedPreferences("settings", Context.MODE_PRIVATE).getString("language", "ru") ?: "ru"
        val configuration = Configuration(newBase.resources.configuration).apply { setLocale(Locale(language)) }
        super.attachBaseContext(newBase.createConfigurationContext(configuration))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { EngineInitializer.initialize(this) }
            .onFailure { QueueStore.appendLog(this, "ERROR", "Engine initialization: ${it.message}") }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val active = QueueStore.activeId(this)
        if (!active.isNullOrBlank()) DownloadService.resumeSaved(this)
        setContent { YtSageApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun YtSageApp(activity: MainActivity) {
    val context = activity
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    val cookiesFile = remember { File(context.filesDir, "cookies.txt") }
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(prefs.getString("draft_url", "") ?: "") }
    var busyAnalyze by remember { mutableStateOf(false) }
    var format by remember { mutableStateOf("video") }
    var selectedQuality by remember { mutableStateOf<Int?>(null) }
    var qualityMenu by remember { mutableStateOf(false) }
    var splitMode by remember { mutableStateOf(QueueStore.SplitMode.NONE) }
    var sizePreset by remember { mutableIntStateOf(500) }
    var customSizeMb by remember { mutableStateOf("500") }
    var startText by remember { mutableStateOf("00:00:00") }
    var endText by remember { mutableStateOf("") }
    var cookiesLoaded by remember { mutableStateOf(cookiesFile.exists()) }
    var metadata by remember { mutableStateOf<MetadataAnalyzer.Result?>(null) }
    var metadataExpanded by remember { mutableStateOf(true) }
    var selectedEntries by remember { mutableStateOf<Set<String>>(emptySet()) }
    var completedExpanded by remember { mutableStateOf(false) }
    var settingsDialogOpen by remember { mutableStateOf(false) }
    var tasks by remember { mutableStateOf(QueueStore.all(context)) }
    var logs by remember { mutableStateOf(QueueStore.logs(context)) }
    val logScroll = rememberScrollState()
    var languageMenu by remember { mutableStateOf(false) }
    var sizeMenu by remember { mutableStateOf(false) }
    var updateBusy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            tasks = QueueStore.all(context)
            logs = QueueStore.logs(context)
            delay(800)
        }
    }
    LaunchedEffect(logs.lastOrNull()?.at, logs.lastOrNull()?.message, logs.size) {
        delay(60)
        logScroll.animateScrollTo(logScroll.maxValue)
    }

    val logExportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri: Uri? ->
        if (uri != null) scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val exportText = QueueStore.logs(context).joinToString("\n") { line ->
                        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(line.at))
                        "$timestamp  ${line.level}  ${line.message}"
                    }
                    context.contentResolver.openOutputStream(uri, "w")?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
                        writer.write(exportText)
                        writer.flush()
                    } ?: error("Cannot open destination file")
                }
            }
            result.onSuccess { QueueStore.appendLog(context, "INFO", context.getString(R.string.logs_saved)) }
                .onFailure { QueueStore.appendLog(context, "ERROR", context.getString(R.string.logs_save_error, it.message ?: it.javaClass.simpleName)) }
        }
    }

    val cookiePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    context.contentResolver.openInputStream(uri)?.use { input -> cookiesFile.outputStream().use { output -> input.copyTo(output) } }
                        ?: error("Cannot open file")
                    val lines = cookiesFile.readLines().take(40)
                    if (lines.none { it.contains("# Netscape HTTP Cookie File") || it.contains(".youtube.com") || it.contains("youtube.com") }) {
                        cookiesFile.delete(); error(context.getString(R.string.cookies_invalid))
                    }
                    context.getString(R.string.cookies_imported)
                } catch (e: Exception) {
                    cookiesFile.delete(); context.getString(R.string.cookies_import_error, e.message ?: e.javaClass.simpleName)
                }
            }
            cookiesLoaded = cookiesFile.exists()
            QueueStore.appendLog(context, if (cookiesLoaded) "INFO" else "ERROR", result)
        }
    }

    fun removeTask(taskId: String) {
        scope.launch {
            withContext(Dispatchers.IO) { QueueStore.delete(context, taskId) }
            tasks = QueueStore.all(context)
        }
    }

    fun updateYtDlp() {
        if (updateBusy || busyAnalyze || tasks.any { it.state == QueueStore.State.RUNNING }) return
        updateBusy = true
        QueueStore.appendLog(context, "INFO", context.getString(R.string.log_update_started))
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val update = YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel._STABLE)
                    context.getString(R.string.ytdlp_updated, update, YoutubeDL.getInstance().versionName(context))
                }
            }
            updateBusy = false
            result.onSuccess { QueueStore.appendLog(context, "INFO", it) }
                .onFailure { QueueStore.appendLog(context, "ERROR", context.getString(R.string.ytdlp_update_error, it.message ?: it.javaClass.simpleName)) }
        }
    }

    fun validateAndMakeTask(videoUrl: String, title: String, thumbnail: String, duration: Int, estimate: Long, batchId: String = ""): QueueStore.Task? {
        if (!videoUrl.startsWith("http://") && !videoUrl.startsWith("https://")) {
            QueueStore.appendLog(context, "ERROR", context.getString(R.string.invalid_url)); return null
        }
        var start = 0
        var end = 0
        if (splitMode == QueueStore.SplitMode.TIME) {
            val parsedStart = parseTimecode(startText)
            val parsedEnd = if (endText.isBlank()) 0 else parseTimecode(endText)
            if (parsedStart == null || (endText.isNotBlank() && parsedEnd == null)) {
                QueueStore.appendLog(context, "ERROR", context.getString(R.string.time_invalid_format)); return null
            }
            start = parsedStart
            end = parsedEnd ?: 0
            if (end > 0 && end <= start) {
                QueueStore.appendLog(context, "ERROR", context.getString(R.string.invalid_time_range)); return null
            }
            if (duration > 0 && (start >= duration || end > duration)) {
                QueueStore.appendLog(context, "ERROR", context.getString(R.string.time_exceeds_duration)); return null
            }
        }
        val targetBytes = when (splitMode) {
            QueueStore.SplitMode.SIZE -> {
                val mb = if (sizePreset == -1) customSizeMb.toLongOrNull() else sizePreset.toLong()
                if (mb == null || mb <= 0L || mb > Long.MAX_VALUE / (1024L * 1024L)) {
                    QueueStore.appendLog(context, "ERROR", context.getString(R.string.custom_size_invalid)); return null
                }
                mb * 1024L * 1024L
            }
            else -> 0L
        }
        val task = QueueStore.Task(
            batchId = batchId, url = videoUrl, title = title, thumbnail = thumbnail,
            format = format, quality = selectedQuality ?: -1, splitMode = splitMode,
            splitBytes = targetBytes, startSeconds = start, endSeconds = end,
            durationSeconds = duration, estimatedBytes = estimate,
            cookiesPath = if (cookiesLoaded) cookiesFile.absolutePath else ""
        )
        val queued = QueueStore.enqueue(context, task)
        if (queued.id != task.id) {
            QueueStore.appendLog(context, "WARN", context.getString(R.string.queue_duplicate))
            return null
        }
        return queued
    }

    fun estimateForQuality(): Long {
        val m = metadata ?: return 0L
        if (format == "audio") return m.audioEstimatedBytes
        return (m.formats.firstOrNull { it.height == (selectedQuality ?: m.formats.maxOfOrNull { f -> f.height }) }?.estimatedBytes ?: m.estimatedBytes)
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(topBar = {
            TopAppBar(
                title = { Text("YTSage Android", fontWeight = FontWeight.Bold) },
                actions = {
                    TextButton(onClick = { settingsDialogOpen = true }) {
                        Text("⚙", style = MaterialTheme.typography.titleLarge)
                    }
                    Box {
                        TextButton(onClick = { languageMenu = true }) { Text(prefs.getString("language", "ru")?.uppercase() ?: "RU") }
                        DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                            DropdownMenuItem(text = { Text(stringResource(R.string.russian)) }, onClick = {
                                prefs.edit().putString("language", "ru").apply(); languageMenu = false; activity.recreate()
                            })
                            DropdownMenuItem(text = { Text(stringResource(R.string.english)) }, onClick = {
                                prefs.edit().putString("language", "en").apply(); languageMenu = false; activity.recreate()
                            })
                        }
                    }
                }
            )
        }) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                OutlinedTextField(
                    value = url,
                    onValueChange = {
                        if (it != url) {
                            metadata = null
                            selectedEntries = emptySet()
                            selectedQuality = null
                        }
                        url = it
                        prefs.edit().putString("draft_url", it).apply()
                    },
                    modifier = Modifier.fillMaxWidth(0.90f).align(Alignment.CenterHorizontally),
                    label = { Text(stringResource(R.string.paste_url)) }, singleLine = true,
                    trailingIcon = {
                        if (url.isNotBlank()) {
                            TextButton(onClick = {
                                url = ""
                                metadata = null
                                selectedEntries = emptySet()
                                selectedQuality = null
                                prefs.edit().putString("draft_url", "").apply()
                            }) { Text(stringResource(R.string.clear_url)) }
                        }
                    },
                    minLines = 1, maxLines = 1
                )

                Text(stringResource(R.string.format), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = format == "video", onClick = { format = "video" }, label = { Text(stringResource(R.string.video)) })
                    FilterChip(selected = format == "audio", onClick = { format = "audio" }, label = { Text(stringResource(R.string.audio)) })
                }

                if (format == "video") {
                    ExposedDropdownMenuBox(expanded = qualityMenu, onExpandedChange = { qualityMenu = !qualityMenu }) {
                        OutlinedTextField(
                            value = selectedQuality?.let { "${it}p" } ?: stringResource(R.string.best_available),
                            onValueChange = {}, readOnly = true, label = { Text(stringResource(R.string.quality)) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = qualityMenu) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = qualityMenu, onDismissRequest = { qualityMenu = false }) {
                            DropdownMenuItem(text = { Text(stringResource(R.string.best_available)) }, onClick = { selectedQuality = null; qualityMenu = false })
                            (metadata?.formats ?: emptyList()).forEach { info ->
                                DropdownMenuItem(text = { Text("${info.height}p  ·  ${formatBytes(info.estimatedBytes)}") }, onClick = { selectedQuality = info.height; qualityMenu = false })
                            }
                        }
                    }
                }

                Text(stringResource(R.string.split), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        modifier = Modifier.weight(1f).height(56.dp),
                        selected = splitMode == QueueStore.SplitMode.NONE,
                        onClick = { splitMode = QueueStore.SplitMode.NONE },
                        label = { Text(stringResource(R.string.no_split), maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
                    )
                    FilterChip(
                        modifier = Modifier.weight(1f).height(56.dp),
                        selected = splitMode == QueueStore.SplitMode.SIZE,
                        onClick = { splitMode = QueueStore.SplitMode.SIZE },
                        label = { Text(stringResource(R.string.split_size), maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
                    )
                    FilterChip(
                        modifier = Modifier.weight(1f).height(56.dp),
                        selected = splitMode == QueueStore.SplitMode.TIME,
                        onClick = { splitMode = QueueStore.SplitMode.TIME },
                        label = { Text(stringResource(R.string.split_time), maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
                    )
                }
                if (splitMode == QueueStore.SplitMode.SIZE) {
                    ExposedDropdownMenuBox(expanded = sizeMenu, onExpandedChange = { sizeMenu = !sizeMenu }) {
                        OutlinedTextField(
                            value = when (sizePreset) { 500 -> "500 MB"; 1024 -> "1 GB"; else -> stringResource(R.string.custom_mb) },
                            onValueChange = {}, readOnly = true, label = { Text(stringResource(R.string.target_size)) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sizeMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = sizeMenu, onDismissRequest = { sizeMenu = false }) {
                            DropdownMenuItem(text = { Text("500 MB") }, onClick = { sizePreset = 500; sizeMenu = false })
                            DropdownMenuItem(text = { Text("1 GB") }, onClick = { sizePreset = 1024; sizeMenu = false })
                            DropdownMenuItem(text = { Text(stringResource(R.string.custom_mb)) }, onClick = { sizePreset = -1; sizeMenu = false })
                        }
                    }
                    if (sizePreset == -1) OutlinedTextField(value = customSizeMb, onValueChange = { customSizeMb = it.filter(Char::isDigit) }, label = { Text(stringResource(R.string.custom_mb)) }, modifier = Modifier.fillMaxWidth())
                    Text(stringResource(R.string.split_size_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (splitMode == QueueStore.SplitMode.TIME) {
                    OutlinedTextField(value = startText, onValueChange = { startText = it }, label = { Text(stringResource(R.string.start_time)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = endText, onValueChange = { endText = it }, label = { Text(stringResource(R.string.end_time)) }, modifier = Modifier.fillMaxWidth())
                }

                Button(
                    onClick = {
                        if (url.isBlank() || (!url.trim().startsWith("http://") && !url.trim().startsWith("https://"))) {
                            QueueStore.appendLog(context, "ERROR", context.getString(R.string.invalid_url)); return@Button
                        }
                        busyAnalyze = true
                        metadata = null; metadataExpanded = true; selectedEntries = emptySet(); selectedQuality = null
                        QueueStore.appendLog(context, "INFO", context.getString(R.string.analysis_started))
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { runCatching { MetadataAnalyzer.analyze(context, url.trim(), cookiesFile) } }
                            busyAnalyze = false
                            result.onSuccess {
                                metadata = it
                                metadataExpanded = true
                                QueueStore.appendLog(context, "INFO", context.getString(R.string.analysis_success, it.message))
                            }.onFailure { QueueStore.appendLog(context, "ERROR", context.getString(R.string.analysis_error, it.message ?: it.javaClass.simpleName)) }
                        }
                    }, modifier = Modifier.fillMaxWidth(), enabled = !busyAnalyze && !updateBusy && tasks.none { it.state == QueueStore.State.RUNNING }
                ) { Text(if (busyAnalyze) stringResource(R.string.analysis_started) else stringResource(R.string.analysis)) }

                metadata?.let { data ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(stringResource(R.string.metadata), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                TextButton(onClick = { metadataExpanded = !metadataExpanded }) {
                                    Text(if (metadataExpanded) stringResource(R.string.collapse) else stringResource(R.string.expand))
                                }
                            }
                            Text(data.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            if (data.durationSeconds > 0) Text("${stringResource(R.string.duration)}: ${formatTimecode(data.durationSeconds)}")
                            if (metadataExpanded) {
                                if (data.thumbnail.isNotBlank()) AsyncImage(model = data.thumbnail, contentDescription = data.title, modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp))
                                if (data.isPlaylist) {
                                    Text(stringResource(R.string.playlist), fontWeight = FontWeight.SemiBold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        TextButton(onClick = { selectedEntries = data.entries.map { it.url }.toSet() }) { Text(stringResource(R.string.select_all)) }
                                        TextButton(onClick = { selectedEntries = emptySet() }) { Text(stringResource(R.string.clear_selection)) }
                                    }
                                    if (data.entries.isEmpty()) Text(stringResource(R.string.no_playlist_entries))
                                    data.entries.forEach { entry ->
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Checkbox(checked = selectedEntries.contains(entry.url), onCheckedChange = { checked ->
                                                selectedEntries = if (checked) selectedEntries + entry.url else selectedEntries - entry.url
                                            })
                                            if (entry.thumbnail.isNotBlank()) AsyncImage(model = entry.thumbnail, contentDescription = null, modifier = Modifier.width(72.dp).height(48.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(entry.title, style = MaterialTheme.typography.bodyMedium)
                                                if (entry.duration > 0) Text(formatTimecode(entry.duration), style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                } else {
                                    Text("${stringResource(R.string.estimated_size)}: ${formatBytes(estimateForQuality())}")
                                    Text("${stringResource(R.string.formats)}: ${data.formats.joinToString { "${it.height}p (${formatBytes(it.estimatedBytes)})" }.ifBlank { "—" }}")
                                }
                            }
                            if (data.isPlaylist) {
                                Button(onClick = {
                                    val chosen = data.entries.filter { selectedEntries.contains(it.url) }
                                    if (chosen.isEmpty()) {
                                        QueueStore.appendLog(context, "WARN", context.getString(R.string.nothing_selected))
                                    } else {
                                        val batch = UUID.randomUUID().toString()
                                        val added = chosen.mapNotNull { entry ->
                                            validateAndMakeTask(entry.url, entry.title, entry.thumbnail, entry.duration, 0L, batch)
                                        }
                                        if (added.isNotEmpty()) {
                                            QueueStore.appendLog(context, "INFO", context.getString(R.string.queue_added, added.size.toString()))
                                            DownloadService.start(context)
                                        } else {
                                            QueueStore.appendLog(context, "WARN", context.getString(R.string.queue_duplicate))
                                        }
                                    }
                                }, modifier = Modifier.fillMaxWidth(), enabled = data.entries.isNotEmpty()) {
                                    Text("${stringResource(R.string.add_selected)} (${selectedEntries.size})")
                                }
                            } else {
                                Button(onClick = {
                                    val task = validateAndMakeTask(url.trim(), data.title, data.thumbnail, data.durationSeconds, estimateForQuality())
                                    if (task != null) {
                                        QueueStore.appendLog(context, "INFO", context.getString(R.string.queue_added, data.title))
                                        DownloadService.start(context)
                                    }
                                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.add_to_queue)) }
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { DownloadService.start(context) }, enabled = tasks.any { it.state == QueueStore.State.WAITING } && tasks.none { it.state == QueueStore.State.RUNNING }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.start_queue)) }
                    OutlinedButton(onClick = { DownloadService.stop(context) }, enabled = tasks.any { it.state == QueueStore.State.RUNNING }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.stop)) }
                }

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(stringResource(R.string.queue), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        val activeTasks = tasks.filter { it.state != QueueStore.State.COMPLETED }
                        val completedTasks = tasks.filter { it.state == QueueStore.State.COMPLETED }
                        if (tasks.isEmpty()) Text(stringResource(R.string.queue_empty), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        activeTasks.forEachIndexed { index, task ->
                            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(task.title.ifBlank { task.url }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                        Text(stateText(task.state), style = MaterialTheme.typography.labelSmall, color = when (task.state) {
                                            QueueStore.State.FAILED -> MaterialTheme.colorScheme.error
                                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                                        })
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                            QueueTag(taskQualityLabel(context, task))
                                            val splitLabel = taskSplitLabel(context, task)
                                            if (splitLabel.isNotBlank()) QueueTag(splitLabel)
                                        }
                                    }
                                    if (task.state != QueueStore.State.RUNNING) {
                                        if (task.state == QueueStore.State.FAILED || task.state == QueueStore.State.CANCELLED) {
                                            TextButton(onClick = {
                                                QueueStore.update(context, task.id) { it.copy(state = QueueStore.State.WAITING, progress = 0f, detail = "") }
                                                DownloadService.start(context)
                                            }) { Text(stringResource(R.string.retry)) }
                                        }
                                        TextButton(onClick = { removeTask(task.id) }) { Text(stringResource(R.string.remove)) }
                                    }
                                }
                                if (task.state == QueueStore.State.RUNNING || task.progress > 0f) {
                                    LinearProgressIndicator(progress = { task.progress.coerceIn(0f, 100f) / 100f }, modifier = Modifier.fillMaxWidth())
                                    Text("${task.progress.toInt()}%", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            if (index != activeTasks.lastIndex || completedTasks.isNotEmpty()) HorizontalDivider()
                        }
                        if (completedTasks.isNotEmpty()) {
                            TextButton(onClick = { completedExpanded = !completedExpanded }, modifier = Modifier.fillMaxWidth()) {
                                Text("${if (completedExpanded) "▼" else "▶"} ${context.getString(R.string.completed_count, completedTasks.size)}")
                            }
                            if (completedExpanded) {
                                completedTasks.forEachIndexed { index, task ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(task.title.ifBlank { task.url }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                            Text(stateText(task.state), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                QueueTag(taskQualityLabel(context, task))
                                                val splitLabel = taskSplitLabel(context, task)
                                                if (splitLabel.isNotBlank()) QueueTag(splitLabel)
                                            }
                                        }
                                        TextButton(onClick = { removeTask(task.id) }) { Text(stringResource(R.string.remove)) }
                                    }
                                    if (index != completedTasks.lastIndex) HorizontalDivider()
                                }
                            }
                        }
                    }
                }

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(R.string.logs), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault()).format(Date())
                                logExportPicker.launch("YTSage-logs-$stamp.txt")
                            }) { Text(stringResource(R.string.save_logs)) }
                            TextButton(onClick = { QueueStore.clearLogs(context) }) { Text(stringResource(R.string.clear_logs)) }
                        }
                        if (logs.isEmpty()) Text("—", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Column(
                            Modifier.fillMaxWidth().heightIn(max = 240.dp).verticalScroll(logScroll),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            logs.takeLast(250).forEach { log ->
                                val time = remember(log.at) { SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(log.at)) }
                                Text(
                                    "$time  ${log.level}  ${log.message}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (log.level == "ERROR") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
                Text(stringResource(R.string.version), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (settingsDialogOpen) {
            AlertDialog(
                onDismissRequest = { if (!updateBusy) settingsDialogOpen = false },
                title = { Text(stringResource(R.string.settings)) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(stringResource(R.string.cookies), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            OutlinedButton(
                                onClick = { cookiePicker.launch(arrayOf("text/*", "application/octet-stream", "*/*")) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (cookiesLoaded) stringResource(R.string.replace_cookies) else stringResource(R.string.load_cookies))
                            }
                            if (cookiesLoaded) {
                                Text(stringResource(R.string.cookies_saved), style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = {
                                    cookiesFile.delete()
                                    cookiesLoaded = false
                                    QueueStore.appendLog(context, "INFO", context.getString(R.string.cookies_removed))
                                }) { Text(stringResource(R.string.delete_cookies)) }
                            } else {
                                Text(stringResource(R.string.cookies_help), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        HorizontalDivider()
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(stringResource(R.string.ytdlp_settings), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            OutlinedButton(
                                onClick = { updateYtDlp() },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !updateBusy && !busyAnalyze && tasks.none { it.state == QueueStore.State.RUNNING }
                            ) {
                                Text(if (updateBusy) stringResource(R.string.ytdlp_updating) else stringResource(R.string.update_ytdlp))
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { if (!updateBusy) settingsDialogOpen = false }, enabled = !updateBusy) {
                        Text(stringResource(R.string.close))
                    }
                }
            )
        }
    }
}

@Composable
private fun QueueTag(text: String) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        shape = RoundedCornerShape(50),
        modifier = Modifier.widthIn(max = 250.dp)
    ) {
        Text(text, modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

private fun taskQualityLabel(context: Context, task: QueueStore.Task): String = when {
    task.format == "audio" -> context.getString(R.string.queue_quality_audio)
    task.quality < 0 -> context.getString(R.string.best_available)
    else -> "${task.quality}p"
}

private fun taskSplitLabel(context: Context, task: QueueStore.Task): String = when (task.splitMode) {
    QueueStore.SplitMode.NONE -> ""
    QueueStore.SplitMode.SIZE -> context.getString(R.string.queue_split_size, formatBytes(task.splitBytes))
    QueueStore.SplitMode.TIME -> context.getString(
        R.string.queue_split_time,
        formatTimecode(task.startSeconds),
        if (task.endSeconds > 0) formatTimecode(task.endSeconds) else context.getString(R.string.until_end)
    )
}

@Composable
private fun stateText(state: QueueStore.State): String = when (state) {
    QueueStore.State.WAITING -> stringResource(R.string.state_waiting)
    QueueStore.State.RUNNING -> stringResource(R.string.state_running)
    QueueStore.State.COMPLETED -> stringResource(R.string.state_completed)
    QueueStore.State.FAILED -> stringResource(R.string.state_failed)
    QueueStore.State.CANCELLED -> stringResource(R.string.state_cancelled)
}
