package com.example.ytsageandroid

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

private val MEDIA_EXTENSIONS = setOf("mp4", "mp3", "m4a", "webm", "mkv")

class DownloadService : Service() {
    companion object {
        const val ACTION_START = "com.example.ytsageandroid.action.START"
        const val ACTION_STOP = "com.example.ytsageandroid.action.STOP"
        private const val CHANNEL_ID = "ytsage_downloads"
        private const val NOTIFICATION_ID = 4102
        private const val PROCESS_ID = "YTSageDownload"

        fun start(context: android.content.Context, taskId: String) {
            val intent = Intent(context, DownloadService::class.java).apply {
                action = ACTION_START
                putExtra("task_id", taskId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }

        fun stop(context: android.content.Context) {
            context.startService(Intent(context, DownloadService::class.java).setAction(ACTION_STOP))
        }

        fun resumeSaved(context: android.content.Context) {
            val intent = Intent(context, DownloadService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var store: QueueStore
    private var wakeLock: PowerManager.WakeLock? = null
    @Volatile private var running = false
    @Volatile private var stopRequested = false

    override fun onCreate() {
        super.onCreate()
        store = QueueStore(this)
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopRequested = true
            try { YoutubeDL.getInstance().destroyProcessById(PROCESS_ID) } catch (_: Exception) { }
            val id = store.activeId()
            if (id != null) {
                store.update(id) { it.copy(status = QueueStore.CANCELLED, detail = "Остановлено пользователем") }
                store.appendLog("Загрузка остановлена пользователем")
            }
            store.setActiveId(null)
            if (!running) stopSelf(startId)
            return START_NOT_STICKY
        }

        // Crucially, a null sticky restart resumes only the exact saved active task ID.
        // It never scans the temporary download directory and never starts arbitrary old files.
        val requestedId = if (intent?.action == ACTION_START) intent.getStringExtra("task_id") else store.activeId()
        val task = requestedId?.let(store::get)
        if (task == null || (intent?.action != ACTION_START && task.status != QueueStore.RUNNING)) {
            store.appendLog("Автовосстановление пропущено: активная задача не подтверждена")
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (running) return START_STICKY

        store.setActiveId(task.id)
        if (task.status == QueueStore.QUEUED) store.update(task.id) { it.copy(status = QueueStore.RUNNING, detail = "Подготовка") }
        startForeground(NOTIFICATION_ID, buildNotification("Подготавливаю: ${task.title}", 0, true))
        running = true
        stopRequested = false
        acquireWakeLock()
        scope.launch {
            try {
                processTaskAndQueue(task.id)
            } finally {
                running = false
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun processTaskAndQueue(firstId: String) {
        var currentId: String? = firstId
        while (currentId != null && !stopRequested) {
            val task = store.get(currentId)
            if (task == null) {
                store.appendLog("Задача $currentId не найдена", true)
                store.setActiveId(null)
                break
            }
            store.setActiveId(task.id)
            store.update(task.id) { it.copy(status = QueueStore.RUNNING, detail = "Подготовка", progress = it.progress.coerceAtLeast(0f)) }
            try {
                downloadTask(task)
                store.update(task.id) { it.copy(status = QueueStore.COMPLETED, detail = "Готово", progress = 100f) }
                store.appendLog("Завершено: ${task.title}")
                showFinalNotification("Загрузка завершена", task.title)
            } catch (e: CancellationException) {
                store.update(task.id) { it.copy(status = QueueStore.CANCELLED, detail = "Операция отменена") }
                store.appendLog("Отменено: ${task.title}")
                if (stopRequested) break
            } catch (e: Exception) {
                store.update(task.id) { it.copy(status = QueueStore.ERROR, detail = e.message ?: e.javaClass.simpleName) }
                store.appendLog("Ошибка ${task.title}: ${e.message ?: e.javaClass.simpleName}", true)
                showFinalNotification("Ошибка загрузки", e.message ?: "Неизвестная ошибка")
            }
            store.setActiveId(null)
            currentId = if (stopRequested) null else store.nextQueued()?.id
        }
        store.setActiveId(null)
    }

    private fun downloadTask(task: DownloadTask) {
        val base = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: File(filesDir, "Downloads")
        val workDir = File(File(base, "YTSageAndroid/work"), task.id)
        if (!workDir.exists() && !workDir.mkdirs()) error("Не удалось создать рабочую папку задачи")

        val duration = task.durationSeconds
        val start = task.startSeconds ?: 0
        val requestedEnd = task.endSeconds ?: duration
        val end = when {
            requestedEnd == null -> null
            duration != null -> requestedEnd.coerceAtMost(duration)
            else -> requestedEnd
        }
        if (end != null && end <= start) error("Конец фрагмента должен быть позже начала")

        val sections = buildSections(task, start, end)
        val segmented = sections.size > 1 || task.startSeconds != null || task.endSeconds != null || task.splitBytes != null
        val folder = if (segmented) safeFileName(task.title) else null
        var overallDone = 0

        sections.forEachIndexed { index, section ->
            if (stopRequested) throw CancellationException("Отменено пользователем")
            val before = workDir.listFiles()?.map { it.name }?.toSet() ?: emptySet()
            val rangeLabel = if (segmented) " [${secondsToTimeCode(section.first)}-${section.second?.let(::secondsToTimeCode) ?: "end"}]" else ""
            val output = if (segmented) File(workDir, "${safeFileName(task.title)}$rangeLabel.%(ext)s").absolutePath
                else File(workDir, "%(title).180B [%(id)s].%(ext)s").absolutePath
            val request = YoutubeDLRequest(task.url).apply {
                addOption("--no-warnings"); addOption("--no-mtime"); addOption("--no-playlist")
                addOption("--continue"); addOption("--retries", "10"); addOption("--fragment-retries", "10")
                addOption("--file-access-retries", "5"); addOption("--retry-sleep", "5")
                addOption("-o", output)
                if (task.format == "AUDIO") {
                    addOption("-x"); addOption("--audio-format", "mp3"); addOption("--audio-quality", "0")
                } else {
                    val selector = if (task.quality == null) "bestvideo+bestaudio/best"
                        else "bestvideo[height<=${task.quality}]+bestaudio/best[height<=${task.quality}]"
                    addOption("-f", selector); addOption("--merge-output-format", "mp4")
                }
                if (segmented && section.second != null) {
                    addOption("--download-sections", "*${secondsToTimeCode(section.first)}-${secondsToTimeCode(section.second)}")
                    addOption("--force-keyframes-at-cuts")
                } else if (segmented && section.first > 0) {
                    addOption("--download-sections", "*${secondsToTimeCode(section.first)}-")
                    addOption("--force-keyframes-at-cuts")
                }
            }
            store.appendLog("Начало части ${index + 1}/${sections.size}: ${task.title}")
            val response = YoutubeDL.getInstance().execute(request, PROCESS_ID) { percent, eta, line ->
                if (stopRequested) return@execute
                val progress = ((overallDone + percent.coerceIn(0f, 100f) / 100f) / sections.size) * 100f
                val message = line.ifBlank { "${percent.toInt()}% · ETA ${eta}s" }.take(240)
                store.update(task.id) { it.copy(progress = progress, detail = message) }
                store.appendLog(message, isError = line.contains("ERROR", ignoreCase = true))
                getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID,
                    buildNotification("${task.title}: $message", progress.toInt(), true))
            }
            if (stopRequested) throw CancellationException("Отменено пользователем")
            val generated = workDir.listFiles()?.filter { file ->
                file.isFile && file.name !in before && !file.name.endsWith(".part") && file.extension.lowercase(Locale.ROOT) in MEDIA_EXTENSIONS
            } ?: emptyList()
            if (generated.isEmpty()) error("Файл части не найден. ${response.out.takeLast(350)}")
            generated.forEach { publishToDownloads(it, folder) }
            overallDone++
        }
    }

    private fun buildSections(task: DownloadTask, start: Int, end: Int?): List<Pair<Int, Int?>> {
        if (end == null || end <= start) return listOf(start to end)
        val target = task.splitBytes ?: return listOf(start to end)
        val estimate = task.estimatedBytes
        val duration = task.durationSeconds
        if (estimate == null || estimate <= target || duration == null || duration <= 0) {
            store.appendLog("Нарезка по размеру: недостаточно данных для оценки; размерная нарезка пропущена")
            return listOf(start to end)
        }
        val selectedDuration = end - start
        val estimatedRangeBytes = estimate.toDouble() * selectedDuration.toDouble() / duration.toDouble()
        val partDuration = max(60, (selectedDuration * target.toDouble() / estimatedRangeBytes).toInt())
        val parts = ceil(selectedDuration.toDouble() / partDuration.toDouble()).toInt().coerceAtLeast(1)
        val result = mutableListOf<Pair<Int, Int?>>()
        var cursor = start
        while (cursor < end) {
            val next = minOf(end, cursor + partDuration)
            result += cursor to next
            cursor = next
        }
        if (parts > 1) store.appendLog("Нарезка по размеру: ориентировочно $parts частей; фактический размер может отличаться")
        return result
    }

    private fun publishToDownloads(source: File, subfolder: String?) {
        val mime = when (source.extension.lowercase(Locale.ROOT)) {
            "mp4" -> "video/mp4"; "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"
            "webm" -> "video/webm"; "mkv" -> "video/x-matroska"; else -> "application/octet-stream"
        }
        val relative = buildString {
            append(Environment.DIRECTORY_DOWNLOADS).append("/YTSageAndroid")
            if (!subfolder.isNullOrBlank()) append('/').append(subfolder)
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, source.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relative)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Не удалось создать файл в Загрузках")
        try {
            resolver.openOutputStream(uri, "w")?.use { output -> source.inputStream().use { input -> input.copyTo(output) } }
                ?: error("Не удалось открыть конечный файл")
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            source.delete()
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    private fun safeFileName(value: String): String = value.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(100).ifBlank { "YTSage video" }

    private fun buildNotification(message: String, progress: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, DownloadService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("YTSage").setContentText(message.take(120)).setContentIntent(open)
            .setOnlyAlertOnce(true).setOngoing(ongoing).setProgress(100, progress.coerceIn(0, 100), false)
            .addAction(0, "Остановить", stop).build()
    }

    private fun showFinalNotification(title: String, message: String) {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID,
            NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(R.drawable.ic_stat_download)
                .setContentTitle("YTSage · $title").setContentText(message.take(160)).setContentIntent(open).setAutoCancel(true).build())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL_ID, "Загрузки YTSage", NotificationManager.IMPORTANCE_LOW))
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "YTSage:Download").apply { setReferenceCounted(false); acquire() }
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
    }

    override fun onDestroy() {
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }

    private fun secondsToTimeCode(seconds: Int): String = "%02d:%02d:%02d".format(seconds / 3600, (seconds % 3600) / 60, seconds % 60)

}
