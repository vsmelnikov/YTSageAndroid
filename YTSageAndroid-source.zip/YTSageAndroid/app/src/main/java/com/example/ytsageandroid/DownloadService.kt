package com.example.ytsageandroid

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.res.Configuration
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

class DownloadService : Service() {
    companion object {
        const val ACTION_START = "com.example.ytsageandroid.action.START"
        const val ACTION_STOP = "com.example.ytsageandroid.action.STOP"
        const val ACTION_RESUME = "com.example.ytsageandroid.action.RESUME"
        private const val CHANNEL_ID = "ytsage_downloads"
        private const val NOTIFICATION_ID = 4102
        private const val FINAL_NOTIFICATION_ID = 4103

        fun start(context: Context) {
            val i = Intent(context, DownloadService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i) else context.startService(i)
        }
        fun stop(context: Context) = context.startService(Intent(context, DownloadService::class.java).setAction(ACTION_STOP))
        fun resumeSaved(context: Context) {
            val i = Intent(context, DownloadService::class.java).setAction(ACTION_RESUME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i) else context.startService(i)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var running = false
    @Volatile private var stopRequested = false
    @Volatile private var startRequestedWhileRunning = false
    @Volatile private var activeProcessId: String? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun attachBaseContext(newBase: Context) {
        val language = newBase.getSharedPreferences("settings", Context.MODE_PRIVATE).getString("language", "ru") ?: "ru"
        val configuration = Configuration(newBase.resources.configuration).apply { setLocale(Locale(language)) }
        super.attachBaseContext(newBase.createConfigurationContext(configuration))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopRequested = true
                activeProcessId?.let { runCatching { YoutubeDL.getInstance().destroyProcessById(it) } }
                QueueStore.activeId(this)?.let { id ->
                    QueueStore.update(this, id) { it.copy(state = QueueStore.State.CANCELLED, detail = getString(R.string.download_stopped)) }
                    QueueStore.appendLog(this, "WARN", getString(R.string.download_stop_requested))
                }
                if (!running) stopSelf(startId)
                return START_NOT_STICKY
            }
            ACTION_START -> {
                if (running) {
                    startRequestedWhileRunning = true
                    return START_STICKY
                }
                stopRequested = false
                startRequestedWhileRunning = false
            }
            ACTION_RESUME -> {
                if (running) return START_STICKY
                val savedId = QueueStore.activeId(this)
                if (savedId.isNullOrBlank() || QueueStore.get(this, savedId)?.state != QueueStore.State.RUNNING) {
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
                QueueStore.recoverInterrupted(this)
                stopRequested = false
            }
            null -> {
                val savedId = QueueStore.activeId(this)
                if (savedId.isNullOrBlank() || QueueStore.get(this, savedId)?.state != QueueStore.State.RUNNING) {
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
                QueueStore.recoverInterrupted(this)
                stopRequested = false
            }
            else -> return START_NOT_STICKY
        }
        if (running) return START_STICKY
        startForeground(NOTIFICATION_ID, buildNotification(getString(R.string.queue_preparing), 0, true))
        running = true
        acquireWakeLock()
        serviceScope.launch {
            try {
                runQueue()
            } finally {
                running = false
                activeProcessId = null
                QueueStore.setActiveId(this@DownloadService, null)
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private suspend fun runQueue() {
        var processedAny = false
        var emptyChecks = 0
        while (!stopRequested) {
            val task = QueueStore.nextWaiting(this)
            if (task == null) {
                if (startRequestedWhileRunning) {
                    startRequestedWhileRunning = false
                    emptyChecks = 0
                    continue
                }
                // Brief idle grace prevents a queue item added at the end of the previous
                // task from being stranded while the foreground service is shutting down.
                if (emptyChecks++ < 3) {
                    delay(500)
                    continue
                }
                break
            }
            emptyChecks = 0
            processedAny = true
            QueueStore.setActiveId(this, task.id)
            QueueStore.update(this, task.id) { it.copy(state = QueueStore.State.RUNNING, detail = getString(R.string.download_preparing), progress = 0f) }
            QueueStore.appendLog(this, "INFO", "${task.title.ifBlank { task.url }} · ${getString(R.string.download_started)}")
            updateNotification(getString(R.string.download_preparing), 0)
            try {
                EngineInitializer.initialize(this)
                executeTask(task)
                if (stopRequested) {
                    QueueStore.update(this, task.id) { it.copy(state = QueueStore.State.CANCELLED, detail = getString(R.string.download_stopped)) }
                } else {
                    QueueStore.update(this, task.id) { it.copy(state = QueueStore.State.COMPLETED, progress = 100f, detail = getString(R.string.download_completed)) }
                    QueueStore.appendLog(this, "INFO", "${task.title}: ${getString(R.string.download_completed)}")
                }
            } catch (e: CancellationException) {
                QueueStore.update(this, task.id) { it.copy(state = QueueStore.State.CANCELLED, detail = getString(R.string.download_stopped)) }
                QueueStore.appendLog(this, "WARN", "${task.title}: ${getString(R.string.download_stopped)}")
            } catch (e: Exception) {
                val message = e.message ?: e.javaClass.simpleName
                if (stopRequested) {
                    QueueStore.update(this, task.id) { it.copy(state = QueueStore.State.CANCELLED, detail = getString(R.string.download_stopped)) }
                    QueueStore.appendLog(this, "WARN", "${task.title.ifBlank { task.url }}: ${getString(R.string.download_stopped)}")
                } else {
                    QueueStore.update(this, task.id) { it.copy(state = QueueStore.State.FAILED, detail = message) }
                    QueueStore.appendLog(this, "ERROR", "${task.title.ifBlank { task.url }}: $message")
                }
            } finally {
                activeProcessId = null
                QueueStore.setActiveId(this, null)
            }
            if (stopRequested) break
        }
        if (!processedAny) QueueStore.appendLog(this, "INFO", getString(R.string.queue_empty))
        else if (!stopRequested) QueueStore.appendLog(this, "INFO", getString(R.string.queue_finished))
        val failed = QueueStore.all(this).count { it.state == QueueStore.State.FAILED }
        if (stopRequested) {
            showFinalNotification(getString(R.string.download_stopped), getString(R.string.download_stopped))
        } else {
            showFinalNotification(getString(R.string.queue_finished), if (failed > 0) getString(R.string.queue_failed_count, failed) else getString(R.string.queue_done))
        }
    }

    private fun makeSegments(task: QueueStore.Task): List<SplitPlanner.Segment?> = when (task.splitMode) {
        QueueStore.SplitMode.NONE -> listOf(null)
        QueueStore.SplitMode.TIME -> {
            val end = if (task.endSeconds > 0) task.endSeconds else task.durationSeconds
            if (end <= task.startSeconds) error(getString(R.string.invalid_time_range))
            listOf(SplitPlanner.Segment(task.startSeconds, end))
        }
        QueueStore.SplitMode.SIZE -> {
            if (task.splitBytes <= 0L || task.estimatedBytes <= 0L || task.durationSeconds <= 0) {
                error(getString(R.string.size_split_no_estimate))
            }
            runCatching { SplitPlanner.byTargetSize(task.durationSeconds, task.estimatedBytes, task.splitBytes) }
                .getOrElse { error(getString(R.string.size_split_failed)) }
        }
    }

    private fun executeTask(originalTask: QueueStore.Task) {
        val cookies = File(originalTask.cookiesPath)
        var task = originalTask.copy(state = QueueStore.State.RUNNING)
        if ((task.splitMode == QueueStore.SplitMode.SIZE && (task.estimatedBytes <= 0L || task.durationSeconds <= 0)) ||
            (task.splitMode == QueueStore.SplitMode.TIME && task.endSeconds <= 0 && task.durationSeconds <= 0)) {
            QueueStore.appendLog(this, "INFO", "${task.title}: ${getString(R.string.analysis_started)}")
            val details = MetadataAnalyzer.analyze(this, task.url, cookies)
            val estimated = if (task.format == "audio") details.audioEstimatedBytes else {
                val candidates = if (task.quality >= 0) details.formats.filter { it.height <= task.quality } else details.formats
                candidates.maxByOrNull { it.height }?.estimatedBytes ?: 0L
            }
            task = task.copy(
                title = task.title.ifBlank { details.title },
                thumbnail = task.thumbnail.ifBlank { details.thumbnail },
                durationSeconds = if (task.durationSeconds > 0) task.durationSeconds else details.durationSeconds,
                estimatedBytes = if (task.estimatedBytes > 0L) task.estimatedBytes else estimated
            )
            QueueStore.put(this, task)
        }
        val base = File(filesDir, "ytsage_jobs/${task.id}")
        if (!base.exists() && !base.mkdirs()) error(getString(R.string.temp_folder_error))
        val segments = makeSegments(task)
        val firstIncomplete = task.completedParts.coerceIn(0, segments.size)
        if (firstIncomplete >= segments.size) return

        for (index in firstIncomplete until segments.size) {
            if (stopRequested) throw CancellationException("stopped")
            val plannedSegment = segments[index]
            val partDir = File(base, "part_${index + 1}")
            if (!partDir.exists() && !partDir.mkdirs()) error(getString(R.string.temp_folder_error))
            val suffix = if (segments.size > 1 || task.splitMode == QueueStore.SplitMode.TIME) {
                val partStart = plannedSegment?.startSeconds ?: 0
                val partEnd = plannedSegment?.endSeconds ?: task.durationSeconds
                " [${formatTimecode(partStart).replace(':', '-')} — ${formatTimecode(partEnd).replace(':', '-')}]"
            } else ""
            val template = File(partDir, "%(title).180B [%(id)s]$suffix.%(ext)s").absolutePath
            val request = YoutubeDLRequest(task.url).apply {
                addOption("--no-warnings"); addOption("--no-mtime"); addOption("--continue")
                addOption("--retries", "10"); addOption("--fragment-retries", "10")
                addOption("--file-access-retries", "5"); addOption("--retry-sleep", "5")
                addOption("--no-playlist"); addOption("-o", template)
                if (cookies.exists() && cookies.length() > 0) addOption("--cookies", cookies.absolutePath)
                if (task.format == "audio") {
                    addOption("-x"); addOption("--audio-format", "mp3"); addOption("--audio-quality", "0")
                } else {
                    val selector = if (task.quality < 0) "bestvideo+bestaudio/best"
                    else "bestvideo[height<=${task.quality}]+bestaudio/best[height<=${task.quality}]"
                    addOption("-f", selector); addOption("--merge-output-format", "mp4")
                }
                if (plannedSegment != null) {
                    addOption("--download-sections", "*${formatTimecode(plannedSegment.startSeconds)}-${formatTimecode(plannedSegment.endSeconds)}")
                    if (task.format != "audio") addOption("--force-keyframes-at-cuts")
                }
            }
            val processId = "YTSage-${task.id.take(8)}-$index"
            activeProcessId = processId
            QueueStore.appendLog(this, "INFO", if (segments.size > 1) getString(R.string.segment_started, index + 1, segments.size) else getString(R.string.engine_started))
            val response = YoutubeDL.getInstance().execute(request, processId) { percent, eta, line ->
                if (line.isNotBlank()) QueueStore.appendLog(this, if (line.contains("ERROR", true)) "ERROR" else "INFO", line)
                val total = ((index + percent.coerceIn(0f, 100f) / 100f) / segments.size * 100f).coerceIn(0f, 100f)
                QueueStore.update(this, task.id) { it.copy(progress = total, detail = line.take(240).ifBlank { getString(R.string.downloading_eta, eta) }) }
                updateNotification(line.ifBlank { getString(R.string.downloading_eta, eta) }, total.toInt())
            }
            val file = partDir.listFiles()?.filter { it.isFile && it.extension.lowercase(Locale.ROOT) in setOf("mp4", "mp3", "m4a", "webm", "mkv", "opus") && !it.name.endsWith(".part") }
                ?.maxByOrNull { it.lastModified() }
                ?: error("${getString(R.string.output_missing)} ${response.out.takeLast(250)}")
            val folder = if (task.splitMode == QueueStore.SplitMode.NONE) "" else sanitizeFolder(task.title.ifBlank { file.nameWithoutExtension })
            val saved = publishToDownloads(file, folder)
            QueueStore.update(this, task.id) { it.copy(completedParts = index + 1, progress = ((index + 1).toFloat() / segments.size * 100f), detail = getString(R.string.segment_saved, index + 1, segments.size, saved)) }
            QueueStore.appendLog(this, "INFO", getString(R.string.file_saved, saved))
            activeProcessId = null
        }
    }

    private fun sanitizeFolder(name: String): String = name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().trim('.').take(100).ifBlank { "YTSage" }

    private fun publishToDownloads(source: File, subfolder: String): String {
        val mime = when (source.extension.lowercase(Locale.ROOT)) {
            "mp4" -> "video/mp4"; "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"
            "webm" -> "video/webm"; "mkv" -> "video/x-matroska"; "opus" -> "audio/ogg"
            else -> "application/octet-stream"
        }
        val relative = buildString {
            append(Environment.DIRECTORY_DOWNLOADS); append("/YTSageAndroid/")
            if (subfolder.isNotBlank()) { append(subfolder); append('/') }
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, source.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relative)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error(getString(R.string.mediastore_create_error))
        try {
            resolver.openOutputStream(uri, "w")?.use { out -> source.inputStream().use { input -> input.copyTo(out) } }
                ?: error(getString(R.string.mediastore_open_error))
            val publishedRows = resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            if (publishedRows <= 0) error(getString(R.string.mediastore_publish_error))
            source.delete()
            return source.name
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    private fun updateNotification(message: String, progress: Int) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(message, progress, true))
    }

    private fun buildNotification(message: String, progress: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, DownloadService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("YTSage").setContentText(message.take(120)).setContentIntent(open)
            .setOnlyAlertOnce(true).setOngoing(ongoing).setProgress(100, progress.coerceIn(0, 100), false)
            .addAction(0, getString(R.string.stop), stop).build()
    }

    private fun showFinalNotification(title: String, message: String) {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        getSystemService(NotificationManager::class.java).notify(FINAL_NOTIFICATION_ID,
            NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(R.drawable.ic_stat_download).setContentTitle("YTSage · $title")
                .setContentText(message.take(160)).setContentIntent(open).setAutoCancel(true).build())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL_ID, getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW))
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "YTSage:Download").apply { setReferenceCounted(false); acquire() }
    }
    private fun releaseWakeLock() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }; wakeLock = null
    }

    override fun onDestroy() {
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }
}
