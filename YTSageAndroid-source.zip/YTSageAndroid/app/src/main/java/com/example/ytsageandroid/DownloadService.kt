package com.example.ytsageandroid

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

class DownloadService : Service() {
    companion object {
        const val ACTION_START = "com.example.ytsageandroid.action.START"
        const val ACTION_STOP = "com.example.ytsageandroid.action.STOP"
        const val ACTION_RESUME = "com.example.ytsageandroid.action.RESUME"
        private const val CHANNEL_ID = "ytsage_downloads"
        private const val NOTIFICATION_ID = 4102
        private const val PROCESS_ID = "YTSageDownload"
        private const val PREFS = "download_job"

        fun start(context: android.content.Context, url: String, format: String, quality: Int?, cookiesPath: String) {
            val intent = Intent(context, DownloadService::class.java).apply {
                action = ACTION_START
                putExtra("url", url)
                putExtra("format", format)
                putExtra("quality", quality ?: -1)
                putExtra("cookies", cookiesPath)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }

        fun stop(context: android.content.Context) {
            context.startService(Intent(context, DownloadService::class.java).setAction(ACTION_STOP))
        }

        fun resumeSaved(context: android.content.Context) {
            val intent = Intent(context, DownloadService::class.java).setAction(ACTION_RESUME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var wakeLock: PowerManager.WakeLock? = null
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                try { YoutubeDL.getInstance().destroyProcessById(PROCESS_ID) } catch (_: Exception) {}
                updateState("Остановка…", 0f, true)
                return START_NOT_STICKY
            }
            ACTION_START -> {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString("url", intent.getStringExtra("url"))
                    .putString("format", intent.getStringExtra("format"))
                    .putInt("quality", intent.getIntExtra("quality", -1))
                    .putString("cookies", intent.getStringExtra("cookies"))
                    .putBoolean("active", true)
                    .apply()
            }
            ACTION_RESUME, null -> Unit
            else -> return START_NOT_STICKY
        }

        if (running) return START_STICKY
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val url = prefs.getString("url", null)
        if (url.isNullOrBlank()) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification("Подготавливаю загрузку", 0, true))
        running = true
        acquireWakeLock()
        serviceScope.launch {
            try { runDownload() }
            finally {
                running = false
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun runDownload() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val url = prefs.getString("url", "") ?: ""
        val format = prefs.getString("format", "Видео · MP4") ?: "Видео · MP4"
        val quality = prefs.getInt("quality", -1)
        val cookies = File(prefs.getString("cookies", "") ?: "")
        val appDownloads = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: File(filesDir, "Downloads")
        val dir = File(appDownloads, "YTSageAndroid")
        if (!dir.exists() && !dir.mkdirs()) {
            finishWithError("Не удалось создать временную папку приложения")
            return
        }
        val before = dir.listFiles()?.associate { it.absolutePath to (it.lastModified() to it.length()) } ?: emptyMap()
        val startedAt = System.currentTimeMillis()
        try {
            val request = YoutubeDLRequest(url).apply {
                addOption("--no-warnings")
                addOption("--no-mtime")
                addOption("--continue")
                addOption("--retries", "10")
                addOption("--fragment-retries", "10")
                addOption("--file-access-retries", "5")
                addOption("--retry-sleep", "5")
                addOption("-o", File(dir, "%(title).180B [%(id)s].%(ext)s").absolutePath)
                if (cookies.exists() && cookies.length() > 0) addOption("--cookies", cookies.absolutePath)
                if (format == "Аудио · MP3") {
                    addOption("-x")
                    addOption("--audio-format", "mp3")
                    addOption("--audio-quality", "0")
                } else {
                    val selector = if (quality < 0) "bestvideo+bestaudio/best"
                    else "bestvideo[height<=${quality}]+bestaudio/best[height<=${quality}]"
                    addOption("-f", selector)
                    addOption("--merge-output-format", "mp4")
                }
            }
            val response = YoutubeDL.getInstance().execute(request, PROCESS_ID) { percent, eta, line ->
                val message = if (line.isBlank()) "Загрузка… ETA ${eta}s" else line.take(180)
                updateState(message, percent, true)
            }
            val supported = setOf("mp4", "mp3", "m4a", "webm", "mkv")
            val completed = dir.listFiles()?.filter { file ->
                if (!file.isFile || file.extension.lowercase(Locale.ROOT) !in supported || file.name.endsWith(".part")) false
                else {
                    val old = before[file.absolutePath]
                    old == null || old.first != file.lastModified() || old.second != file.length() || file.lastModified() >= startedAt - 2000
                }
            } ?: emptyList()
            if (completed.isEmpty()) error("yt-dlp завершился, но готовый медиафайл не найден. ${response.out.takeLast(250)}")
            val names = completed.map { publishToDownloads(it) }
            prefs.edit().putBoolean("active", false).putString("status", "Готово: ${names.joinToString()}").putFloat("progress", 100f).apply()
            showFinalNotification("Загрузка завершена", names.joinToString())
        } catch (e: Exception) {
            finishWithError("Ошибка загрузки: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun publishToDownloads(source: File): String {
        val mime = when (source.extension.lowercase(Locale.ROOT)) {
            "mp4" -> "video/mp4"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            else -> "application/octet-stream"
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, source.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/YTSageAndroid")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Android не смог создать файл в общей папке Загрузки")
        try {
            resolver.openOutputStream(uri, "w")?.use { out -> source.inputStream().use { input -> input.copyTo(out) } }
                ?: error("Не удалось открыть файл назначения")
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            source.delete()
            return source.name
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    private fun finishWithError(message: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("active", false).putString("status", message).apply()
        showFinalNotification("Ошибка загрузки", message)
    }

    private fun updateState(message: String, progress: Float, active: Boolean) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString("status", message).putFloat("progress", progress.coerceIn(0f, 100f)).putBoolean("active", active).apply()
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(message, progress.toInt(), true))
    }

    private fun buildNotification(message: String, progress: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, DownloadService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("YTSage")
            .setContentText(message.take(120))
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .addAction(0, "Остановить", stop)
            .build()
    }

    private fun showFinalNotification(title: String, message: String) {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID,
            NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(R.drawable.ic_stat_download)
                .setContentTitle("YTSage · $title").setContentText(message.take(160)).setContentIntent(open).setAutoCancel(true).build())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Загрузки YTSage", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "YTSage:Download").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    override fun onDestroy() {
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }
}
