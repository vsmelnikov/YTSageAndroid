package com.example.ytsageandroid

import kotlin.math.ceil
import kotlin.math.max

/** Plans standalone time sections from a target byte size and yt-dlp's estimated full size. */
object SplitPlanner {
    data class Segment(val startSeconds: Int, val endSeconds: Int)

    fun byTargetSize(durationSeconds: Int, estimatedBytes: Long, targetBytes: Long): List<Segment> {
        require(durationSeconds > 0) { "Video duration must be positive" }
        require(estimatedBytes > 0L && targetBytes > 0L) { "Estimated and target sizes must be positive" }

        val estimatedCount = ceil(estimatedBytes.toDouble() / targetBytes.toDouble()).toInt().coerceAtLeast(1)
        // A time-based cut cannot create more non-empty sections than there are whole seconds.
        val count = estimatedCount.coerceAtMost(durationSeconds)
        val secondsPerTarget = durationSeconds.toDouble() * targetBytes.toDouble() / estimatedBytes.toDouble()
        val result = ArrayList<Segment>(count)
        var start = 0
        for (index in 0 until count) {
            val end = if (index == count - 1) durationSeconds
            else max((start + 1).toDouble(), (index + 1) * secondsPerTarget).toInt().coerceAtMost(durationSeconds)
            if (end > start) result += Segment(start, end)
            start = end
        }
        check(result.isNotEmpty()) { "No non-empty time sections could be planned" }
        check(result.first().startSeconds == 0 && result.last().endSeconds == durationSeconds)
        check(result.zipWithNext().all { (a, b) -> a.endSeconds == b.startSeconds })
        return result
    }
}
