package com.example.ytsageandroid

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object QueueStore {
    private const val PREFS = "ytsage_queue_v2"
    private const val TASKS = "tasks"
    private const val LOGS = "logs"
    private const val ACTIVE_ID = "active_id"
    private val lock = Any()

    enum class State { WAITING, RUNNING, COMPLETED, FAILED, CANCELLED }
    enum class SplitMode { NONE, SIZE, TIME }

    data class Task(
        val id: String = UUID.randomUUID().toString(),
        val batchId: String = "",
        val url: String,
        val title: String = "",
        val thumbnail: String = "",
        val format: String = "video",
        val quality: Int = -1,
        val splitMode: SplitMode = SplitMode.NONE,
        val splitBytes: Long = 0L,
        val startSeconds: Int = 0,
        val endSeconds: Int = 0,
        val durationSeconds: Int = 0,
        val estimatedBytes: Long = 0L,
        val cookiesPath: String = "",
        val state: State = State.WAITING,
        val progress: Float = 0f,
        val detail: String = "",
        val completedParts: Int = 0,
        val createdAt: Long = System.currentTimeMillis()
    )

    data class LogLine(val at: Long, val level: String, val message: String)

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun all(context: Context): List<Task> = synchronized(lock) {
        val array = JSONArray(prefs(context).getString(TASKS, "[]") ?: "[]")
        (0 until array.length()).mapNotNull { i -> runCatching { fromJson(array.getJSONObject(i)) }.getOrNull() }
            .sortedBy { it.createdAt }
    }

    fun get(context: Context, id: String): Task? = all(context).firstOrNull { it.id == id }

    fun put(context: Context, task: Task) = synchronized(lock) {
        val items = all(context).filterNot { it.id == task.id }.toMutableList().apply { add(task) }
        saveTasks(context, items)
    }

    fun update(context: Context, id: String, transform: (Task) -> Task) = synchronized(lock) {
        val items = all(context).map { if (it.id == id) transform(it) else it }
        saveTasks(context, items)
    }

    fun enqueue(context: Context, task: Task): Task = synchronized(lock) {
        val duplicate = all(context).firstOrNull {
            it.url == task.url && it.quality == task.quality && it.format == task.format &&
                it.splitMode == task.splitMode && it.splitBytes == task.splitBytes &&
                it.startSeconds == task.startSeconds && it.endSeconds == task.endSeconds &&
                it.state in setOf(State.WAITING, State.RUNNING)
        }
        if (duplicate != null) return duplicate
        put(context, task)
        task
    }

    fun delete(context: Context, id: String): Boolean = synchronized(lock) {
        val task = get(context, id) ?: return false
        if (task.state == State.RUNNING) return false
        saveTasks(context, all(context).filterNot { it.id == id })
        true
    }

    fun nextWaiting(context: Context): Task? = all(context).firstOrNull { it.state == State.WAITING }
    fun activeId(context: Context): String? = prefs(context).getString(ACTIVE_ID, null)
    fun setActiveId(context: Context, id: String?) = prefs(context).edit().putString(ACTIVE_ID, id).apply()

    fun appendLog(context: Context, level: String, message: String) = synchronized(lock) {
        if (message.isBlank()) return
        val p = prefs(context)
        val old = JSONArray(p.getString(LOGS, "[]") ?: "[]")
        if (old.length() > 0) {
            val previous = old.optJSONObject(old.length() - 1)
            if (previous?.optString("level") == level && previous.optString("message") == message) return
        }
        val out = JSONArray()
        val start = (old.length() - 399).coerceAtLeast(0)
        for (i in start until old.length()) out.put(old.getJSONObject(i))
        out.put(JSONObject().put("at", System.currentTimeMillis()).put("level", level).put("message", message.take(1000)))
        p.edit().putString(LOGS, out.toString()).apply()
    }

    fun logs(context: Context): List<LogLine> = synchronized(lock) {
        val a = JSONArray(prefs(context).getString(LOGS, "[]") ?: "[]")
        (0 until a.length()).mapNotNull { i ->
            runCatching { a.getJSONObject(i).let { LogLine(it.optLong("at"), it.optString("level"), it.optString("message")) } }.getOrNull()
        }
    }

    fun clearLogs(context: Context) = prefs(context).edit().putString(LOGS, "[]").apply()

    fun recoverInterrupted(context: Context) {
        synchronized(lock) {
            val id = activeId(context)
            if (id != null) {
                val interrupted = get(context, id)
                if (interrupted?.state == State.RUNNING) {
                    update(context, id) { it.copy(state = State.WAITING, detail = context.getString(R.string.queue_recovered)) }
                    appendLog(context, "WARN", context.getString(R.string.queue_recovered))
                }
            }
            setActiveId(context, null)
        }
    }

    private fun saveTasks(context: Context, tasks: List<Task>) {
        val a = JSONArray()
        tasks.forEach { a.put(toJson(it)) }
        prefs(context).edit().putString(TASKS, a.toString()).apply()
    }

    private fun toJson(t: Task) = JSONObject().apply {
        put("id", t.id); put("batchId", t.batchId); put("url", t.url); put("title", t.title)
        put("thumbnail", t.thumbnail); put("format", t.format); put("quality", t.quality)
        put("splitMode", t.splitMode.name); put("splitBytes", t.splitBytes)
        put("startSeconds", t.startSeconds); put("endSeconds", t.endSeconds)
        put("durationSeconds", t.durationSeconds); put("estimatedBytes", t.estimatedBytes)
        put("cookiesPath", t.cookiesPath); put("state", t.state.name); put("progress", t.progress)
        put("detail", t.detail); put("completedParts", t.completedParts); put("createdAt", t.createdAt)
    }

    private fun fromJson(o: JSONObject) = Task(
        id = o.optString("id", UUID.randomUUID().toString()), batchId = o.optString("batchId"),
        url = o.getString("url"), title = o.optString("title"), thumbnail = o.optString("thumbnail"),
        format = o.optString("format", "video"), quality = o.optInt("quality", -1),
        splitMode = runCatching { SplitMode.valueOf(o.optString("splitMode", "NONE")) }.getOrDefault(SplitMode.NONE),
        splitBytes = o.optLong("splitBytes"), startSeconds = o.optInt("startSeconds"), endSeconds = o.optInt("endSeconds"),
        durationSeconds = o.optInt("durationSeconds"), estimatedBytes = o.optLong("estimatedBytes"),
        cookiesPath = o.optString("cookiesPath"), state = runCatching { State.valueOf(o.optString("state", "WAITING")) }.getOrDefault(State.WAITING),
        progress = o.optDouble("progress").toFloat().coerceIn(0f, 100f), detail = o.optString("detail"),
        completedParts = o.optInt("completedParts"), createdAt = o.optLong("createdAt", System.currentTimeMillis())
    )
}
