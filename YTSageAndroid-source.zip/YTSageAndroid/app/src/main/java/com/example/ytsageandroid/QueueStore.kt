package com.example.ytsageandroid

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** A durable queue item. Each job owns its URL, options and output folder. */
data class DownloadTask(
    val id: String = UUID.randomUUID().toString(),
    val url: String,
    val title: String,
    val thumbnail: String? = null,
    val format: String = "VIDEO",
    val quality: Int? = null,
    val estimatedBytes: Long? = null,
    val durationSeconds: Int? = null,
    val startSeconds: Int? = null,
    val endSeconds: Int? = null,
    val splitBytes: Long? = null,
    val status: String = QueueStore.QUEUED,
    val progress: Float = 0f,
    val detail: String = "В очереди",
    val createdAt: Long = System.currentTimeMillis()
)

class QueueStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun all(): List<DownloadTask> = decode(prefs.getString(KEY_TASKS, "[]") ?: "[]")
        .sortedBy { it.createdAt }

    @Synchronized fun get(id: String): DownloadTask? = all().firstOrNull { it.id == id }

    @Synchronized fun enqueue(task: DownloadTask) {
        val items = all().filterNot { it.id == task.id }.toMutableList()
        items.add(task.copy(status = QUEUED, progress = 0f, detail = "В очереди"))
        save(items.takeLast(MAX_TASKS))
        appendLog("Добавлено в очередь: ${task.title}")
    }

    @Synchronized fun update(id: String, transform: (DownloadTask) -> DownloadTask) {
        save(all().map { if (it.id == id) transform(it) else it })
    }

    @Synchronized fun remove(id: String): Boolean {
        val task = get(id) ?: return false
        if (task.status == RUNNING) return false
        save(all().filterNot { it.id == id })
        appendLog("Удалено из очереди: ${task.title}")
        return true
    }

    @Synchronized fun nextQueued(): DownloadTask? = all().firstOrNull { it.status == QUEUED }

    fun activeId(): String? = prefs.getString(KEY_ACTIVE_ID, null)
    fun setActiveId(id: String?) { prefs.edit().putString(KEY_ACTIVE_ID, id).apply() }

    @Synchronized fun appendLog(message: String, isError: Boolean = false) {
        val old = try { JSONArray(prefs.getString(KEY_LOGS, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val next = JSONArray()
        val timestamp = System.currentTimeMillis()
        for (i in maxOf(0, old.length() - MAX_LOGS + 1) until old.length()) next.put(old.optJSONObject(i))
        next.put(JSONObject().put("time", timestamp).put("message", message.take(700)).put("error", isError))
        prefs.edit().putString(KEY_LOGS, next.toString()).apply()
    }

    fun logs(): List<LogLine> {
        val array = try { JSONArray(prefs.getString(KEY_LOGS, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        return (0 until array.length()).mapNotNull { i ->
            array.optJSONObject(i)?.let {
                LogLine(it.optLong("time"), it.optString("message"), it.optBoolean("error"))
            }
        }
    }

    @Synchronized fun clearLogs() { prefs.edit().putString(KEY_LOGS, "[]").apply() }

    private fun save(tasks: List<DownloadTask>) {
        val array = JSONArray()
        tasks.forEach { t ->
            array.put(JSONObject().apply {
                put("id", t.id); put("url", t.url); put("title", t.title); put("thumbnail", t.thumbnail)
                put("format", t.format); put("quality", t.quality); put("estimatedBytes", t.estimatedBytes)
                put("durationSeconds", t.durationSeconds); put("startSeconds", t.startSeconds); put("endSeconds", t.endSeconds); put("splitBytes", t.splitBytes)
                put("status", t.status); put("progress", t.progress.toDouble()); put("detail", t.detail)
                put("createdAt", t.createdAt)
            })
        }
        prefs.edit().putString(KEY_TASKS, array.toString()).apply()
    }

    private fun decode(raw: String): List<DownloadTask> {
        val array = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        return (0 until array.length()).mapNotNull { i ->
            val o = array.optJSONObject(i) ?: return@mapNotNull null
            try {
                DownloadTask(
                    id = o.optString("id"), url = o.optString("url"), title = o.optString("title"),
                    thumbnail = o.optString("thumbnail").takeUnless { it.isBlank() || it == "null" },
                    format = o.optString("format", "VIDEO"),
                    quality = o.optInt("quality", -1).takeIf { it > 0 },
                    estimatedBytes = o.optLong("estimatedBytes", -1).takeIf { it > 0 },
                    durationSeconds = o.optInt("durationSeconds", -1).takeIf { it > 0 },
                    startSeconds = o.optInt("startSeconds", -1).takeIf { it >= 0 },
                    endSeconds = o.optInt("endSeconds", -1).takeIf { it >= 0 },
                    splitBytes = o.optLong("splitBytes", -1).takeIf { it > 0 },
                    status = o.optString("status", QUEUED), progress = o.optDouble("progress", 0.0).toFloat(),
                    detail = o.optString("detail"), createdAt = o.optLong("createdAt", System.currentTimeMillis())
                )
            } catch (_: Exception) { null }
        }
    }

    companion object {
        const val QUEUED = "QUEUED"
        const val RUNNING = "RUNNING"
        const val COMPLETED = "COMPLETED"
        const val CANCELLED = "CANCELLED"
        const val ERROR = "ERROR"
        private const val PREFS = "ytsage_queue_v2"
        private const val KEY_TASKS = "tasks"
        private const val KEY_LOGS = "logs"
        private const val KEY_ACTIVE_ID = "active_task_id"
        private const val MAX_TASKS = 250
        private const val MAX_LOGS = 500
    }
}

data class LogLine(val time: Long, val message: String, val isError: Boolean)
