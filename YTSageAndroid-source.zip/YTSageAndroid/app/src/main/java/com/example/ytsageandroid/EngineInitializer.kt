package com.example.ytsageandroid

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL

object EngineInitializer {
    private val lock = Any()
    @Volatile private var youtubeReady = false
    @Volatile private var ffmpegReady = false

    fun initialize(context: Context) = synchronized(lock) {
        val app = context.applicationContext
        if (!youtubeReady) {
            YoutubeDL.getInstance().init(app)
            youtubeReady = true
        }
        if (!ffmpegReady) {
            FFmpeg.getInstance().init(app)
            ffmpegReady = true
        }
    }
}
