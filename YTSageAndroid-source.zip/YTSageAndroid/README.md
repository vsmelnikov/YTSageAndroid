# YTSage Android 0.2.0

Android 10+ prototype with the yt-dlp Android wrapper and FFmpeg.

## Build
Use JDK 17 and Android SDK 35. GitHub Actions can build the debug APK.

## Engine
The app initializes `youtubedl-android` and FFmpeg, downloads a single URL, reports yt-dlp progress, and writes to app-private temporary storage, then publishes the completed file to `Download/YTSageAndroid` through MediaStore.

The library bundles yt-dlp and Python. See the upstream project and license:
https://github.com/yausername/youtubedl-android

## Device compatibility
Configured for ARM64 and ARMv7. The target device Huawei P30 Pro (Android 11) is ARM64.

## Limitations of this first engine integration
- One URL at a time; no queue or background service yet.
- Progress is the percentage reported by yt-dlp; not all sites/formats report it consistently.
- Final publishing uses Android MediaStore, avoiding broad storage permissions.
- No DRM circumvention.
