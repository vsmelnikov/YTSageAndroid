# YTSage Android 0.4.0-alpha1

Alpha source update: download execution is moved from the Compose screen into an Android foreground service.

Included: persistent notification with Stop action, partial WakeLock, saved job parameters/status, START_STICKY recovery, yt-dlp `--continue` and retry options, retained cookies import/format analysis/MP3-MP4/yt-dlp updater, and new red launcher icon with white download arrow.

Limitations: this source has not yet been compiled or device-tested. Downloads still use app-private temporary storage and are copied into `Downloads/YTSageAndroid` only after completion. Direct MediaStore streaming, quality-size estimates, time ranges, size-based splitting, and English localization are not included in this alpha. Resume depends on server support; fragmented downloads may resume at fragment boundaries. Force-stop from Android Settings prevents automatic service restart; relaunching the app attempts to resume the saved job. Huawei EMUI battery settings may still need to allow background activity.

Build with JDK 17, Gradle 8.9, AGP 8.7.3. Never commit or share cookies.txt.
