# YTSage Android 0.3.1

Android app based on the original YTSage UI prototype and the `youtubedl-android` wrapper for yt-dlp.

## Features in this build
- yt-dlp engine from `io.github.junkfood02.youtubedl-android` 0.18.1
- FFmpeg module for MP3 extraction and MP4 merging
- Analyze video formats and list available video heights
- Download video at selected height or best available quality
- Extract audio to MP3
- Import a Netscape-format `cookies.txt` using Android file picker
- Cookies are copied into app-private storage and are not included in backups or the repository
- Stop current download and update yt-dlp Stable from the app

## Build
Use JDK 17 and Gradle 8.9 with Android Gradle Plugin 8.7.3. Open `YTSageAndroid` in Android Studio or use the repository GitHub Actions workflow.

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Downloads are written to `Downloads/YTSageAndroid`.

## Important
This is a first integrated build and still needs device testing. YouTube may continue to require valid cookies or reject a session; importing cookies does not guarantee access. Never commit `cookies.txt` to GitHub or share it: it contains account session credentials.

The app uses yt-dlp and FFmpeg through the `youtubedl-android` library. Respect applicable site terms and copyright law; this app does not bypass DRM.
