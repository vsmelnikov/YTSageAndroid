# YTSage Android 0.4.1

Android front end for the yt-dlp Android engine. This 0.4.1 source update is built from the 0.4.0-alpha2 archive and keeps its private-temp-file -> MediaStore publishing path.

## Included in this alpha

- Foreground download service with persistent notification, Stop action and partial WakeLock.
- Persistent queue with task-specific IDs, de-duplication, retry/remove controls and active-task recovery after service/process restart.
- yt-dlp continuation and retry options (`--continue`, `--retries`, `--fragment-retries`, `--file-access-retries`). Each task and each split part has its own working directory.
- Per-part publishing: a completed split segment is copied to `Downloads/YTSageAndroid/<video title>/` immediately. An unfinished segment stays in the app-private work directory for a later retry.
- Video/audio selection, resolution list and per-resolution `filesize` / `filesize_approx` display (a dash is shown when yt-dlp reports no size).
- Split by target size (500 MB, 1 GB or custom MB) and by time range. Segment sizes are estimates, not hard limits.
- Video/playlist metadata, thumbnail and playlist item selection. Only checked playlist entries are added to the queue.
- Persisted URL draft, Netscape cookies import, Russian/English UI preference, yt-dlp stable updater.
- Separate queue and process log panels. Queue state is not overwritten by log messages; yt-dlp progress updates one persistent live log row per task instead of flooding the log.
- Collapsible video information panel with the add-to-queue action kept visible, collapsible completed-download group, and a visible URL clear action.
- New queue items and retried items start automatically. Split mode is shown next to each queued item only when enabled.
- Save process logs to a UTF-8 TXT file using Android's document picker.
- Adaptive launcher icon matching the supplied reference: white background, red rounded rectangle, white download arrow and tray.

## Build

Open the `YTSageAndroid` directory in Android Studio (JDK 17, Android SDK 35), or run:

```bash
gradle --no-daemon :app:assembleDebug
```

A GitHub Actions workflow is included at `.github/workflows/android.yml`. It installs Gradle 8.9 and Android SDK 35, builds the debug APK, and uploads it as an artifact.

## Important limitations of this alpha

- Size-based splitting estimates segment duration from yt-dlp's reported media size and duration. Actual output sizes vary with bitrate, keyframes, codec/container overhead and the selected formats.
- A device vendor's battery manager may still stop a foreground process. A user force-stop from Android Settings also prevents automatic restart. Test long downloads with the screen off on the target device and allow background activity for YTSage in system battery settings.
- The service resumes the interrupted active task only. Waiting queue entries remain waiting after an app/service restart until the user explicitly starts the queue; this avoids launching stale jobs unexpectedly.
- Playlist entries are initially loaded using yt-dlp's flat-playlist metadata. Some private, deleted, age-restricted or unsupported entries may not be selectable/downloadable.
- Direct writing into public Downloads is intentionally not used during download. The app writes to a private per-task temporary folder and publishes completed files through MediaStore to avoid exposing incomplete outputs.

## Versioning

`0.4.1` is a source candidate. A successful GitHub Actions build and device testing are still required before treating it as a tested release.
