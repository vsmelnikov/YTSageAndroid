# YTSage Android — стартовый проект

Цель: Android 10+ (minSdk 29), включая Huawei P30 Pro на Android 11.

## Открытие и сборка
1. Установить Android Studio (актуальную стабильную версию).
2. Открыть папку `YTSageAndroid` как проект.
3. Дождаться синхронизации Gradle и установки Android SDK 35, если Android Studio предложит.
4. Выбрать Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Текущий статус
Это стартовый UI-прототип: экран ссылки, выбор режима и область очереди. Реальный движок скачивания yt-dlp/FFmpeg ещё не подключён; кнопка пока только проверяет формат ссылки. Не распространять как готовый загрузчик.
